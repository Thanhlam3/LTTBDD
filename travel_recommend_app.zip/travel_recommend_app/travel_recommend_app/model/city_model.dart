class CityModel {
  int id;
  String name;
  String? imageUrl;
  String? moTa;

  CityModel({
    required this.id,
    required this.name,
    this.imageUrl,
    this.moTa,
  });

  factory CityModel.fromJson(Map<String, dynamic> json) {
    return CityModel(
      id: json['id'],
      name: json['name'],
      imageUrl: json['image_url'],
      moTa: json['description'],
    );
  }
}
