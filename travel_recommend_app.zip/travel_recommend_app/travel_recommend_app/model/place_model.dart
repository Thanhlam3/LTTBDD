class PlaceModel {
  int id;
  int cityId;
  String name;
  String loai; // tham_quan | quan_an | khach_san
  String? diaChi;
  String? imageUrl;
  String? moTa;
  double rating;

  PlaceModel({
    required this.id,
    required this.cityId,
    required this.name,
    required this.loai,
    this.diaChi,
    this.imageUrl,
    this.moTa,
    this.rating = 0,
  });

  factory PlaceModel.fromJson(Map<String, dynamic> json) {
    return PlaceModel(
      id: json['id'],
      cityId: json['city_id'],
      name: json['name'],
      loai: json['type'],
      diaChi: json['address'],
      imageUrl: json['image_url'],
      moTa: json['description'],
      rating: (json['rating'] ?? 0).toDouble(),
    );
  }

  String getTenLoai() {
    if (loai == 'tham_quan') return 'Tham quan';
    if (loai == 'quan_an')   return 'Quán ăn';
    if (loai == 'khach_san') return 'Khách sạn';
    return 'Khác';
  }
}
