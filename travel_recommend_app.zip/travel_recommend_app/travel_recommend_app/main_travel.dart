import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'pages/splash_screen.dart';
import 'controller/auth_controller.dart';

void main() async {
  // Bắt buộc phải gọi trước khi dùng async trong main
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize Supabase TRƯỚC KHI runApp
  await Supabase.initialize(
    url: 'https://vjzmzdzqqcfxfbussxjn.supabase.co',
    anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3Mi'
        'OiJzdXBhYmFzZSIsInJlZiI6InZqem16ZHpxcWNmeGZidXNzeGpuIiwicm9sZSI6ImFub24iLC'
        'JpYXQiOjE3NzUzNzMwNzcsImV4cCI6MjA5MDk0OTA3N30.KbusqXWMJmni3LGSt8TBywfAXbTVce5Mie9VNx63tPE',
  );

  // Đăng ký AuthController toàn cục TRƯỚC KHI runApp
  Get.put(AuthController());

  runApp(const MyApp());
}

// dùng ở mọi nơi trong app — an toàn vì Supabase đã initialize xong
final supabase = Supabase.instance.client;

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'Travel Vietnam',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.teal),
      ),
      home: SplashScreen(),
    );
  }
}