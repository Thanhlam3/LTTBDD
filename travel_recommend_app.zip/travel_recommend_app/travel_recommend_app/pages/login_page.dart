import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:supabase_auth_ui/supabase_auth_ui.dart';
import 'package:flutter_otp_text_field/flutter_otp_text_field.dart';
import 'home_page.dart';

// ============================================
// TRANG ĐĂNG NHẬP / ĐĂNG KÝ
// ============================================
class LoginPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Travel Vietnam'),
        backgroundColor: Colors.teal,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(24),
        child: Column(
          children: [
            SizedBox(height: 40),
            Icon(Icons.travel_explore, size: 80, color: Colors.teal),
            SizedBox(height: 12),
            Text('Khám phá Việt Nam',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            SizedBox(height: 32),

            // SupaEmailAuth tự làm form, không cần TextEditingController
            SupaEmailAuth(
              onSignInComplete: (response) {
                Get.offAll(() => HomePage());
              },
              onSignUpComplete: (response) {
                // đăng ký xong → chuyển sang nhập OTP
                String email = response.user?.email ?? '';
                Get.to(() => PageNhapOTP(email: email));
              },
              localization: SupaEmailAuthLocalization(
                enterEmail: 'Nhập email',
                enterPassword: 'Nhập mật khẩu',
                signIn: 'Đăng nhập',
                signUp: 'Đăng ký',
                forgotPassword: 'Quên mật khẩu?',
                dontHaveAccount: 'Chưa có tài khoản? ',
                haveAccount: 'Đã có tài khoản? ',
                sendPasswordReset: 'Gửi email đặt lại mật khẩu',
                backToSignIn: 'Quay lại đăng nhập',
                unexpectedError: 'Có lỗi xảy ra, thử lại nhé',
                requiredFieldError: 'Không được để trống',
                passwordLengthError: 'Mật khẩu phải có ít nhất 6 ký tự',
              ),
            ),

            // ── Phân cách ──────────────────────────────────────
            Padding(
              padding: EdgeInsets.symmetric(vertical: 16),
              child: Row(
                children: [
                  Expanded(child: Divider(color: Colors.grey[300])),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 12),
                    child: Text('hoặc',
                        style: TextStyle(color: Colors.grey, fontSize: 13)),
                  ),
                  Expanded(child: Divider(color: Colors.grey[300])),
                ],
              ),
            ),

            // ── Nút truy cập không cần tài khoản ───────────────
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                icon: Icon(Icons.explore_outlined, color: Colors.teal),
                label: Text(
                  'Tiếp tục không cần đăng nhập',
                  style: TextStyle(color: Colors.teal),
                ),
                style: OutlinedButton.styleFrom(
                  side: BorderSide(color: Colors.teal),
                  padding: EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                onPressed: () => Get.offAll(() => HomePage()),
              ),
            ),

          ],
        ),
      ),
    );
  }
}


// ============================================
// TRANG NHẬP MÃ OTP 6 SỐ
// ============================================
class PageNhapOTP extends StatefulWidget {
  final String email;
  PageNhapOTP({required this.email});

  @override
  State<PageNhapOTP> createState() => _PageNhapOTPState();
}

class _PageNhapOTPState extends State<PageNhapOTP> {
  bool dangXacThuc = false;

  void xacThucOTP(String maOTP) async {
    setState(() => dangXacThuc = true);
    try {
      final response = await Supabase.instance.client.auth.verifyOTP(
        type: OtpType.email,
        token: maOTP,
        email: widget.email,
      );

      if (response.session != null) {
        Get.offAll(() => HomePage());
      }
    } on AuthException catch (e) {
      Get.snackbar('Sai mã', e.message,
          backgroundColor: Colors.red, colorText: Colors.white);
    } catch (e) {
      Get.snackbar('Lỗi', 'Có lỗi xảy ra',
          backgroundColor: Colors.red, colorText: Colors.white);
    } finally {
      setState(() => dangXacThuc = false);
    }
  }

  void guiLaiOTP() async {
    try {
      await Supabase.instance.client.auth.resend(
        type: OtpType.signup,
        email: widget.email,
      );
      Get.snackbar('Đã gửi lại', 'Kiểm tra hộp thư ${widget.email}',
          backgroundColor: Colors.blue, colorText: Colors.white);
    } catch (e) {
      Get.snackbar('Lỗi', 'Không gửi được, thử lại sau');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Xác thực Email'),
        backgroundColor: Colors.teal,
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.mark_email_read_outlined, size: 80, color: Colors.teal),
            SizedBox(height: 16),
            Text('Nhập mã OTP',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            SizedBox(height: 8),
            Text(
              'Mã 6 số đã gửi về\n${widget.email}',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.grey, fontSize: 14),
            ),
            SizedBox(height: 36),

            // 6 ô nhập OTP
            OtpTextField(
              numberOfFields: 6,
              borderColor: Colors.teal,
              focusedBorderColor: Colors.teal,
              showFieldAsBox: true,
              borderWidth: 2,
              fieldWidth: 45,
              textStyle: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              onCodeChanged: (code) {},
              onSubmit: (maOTP) => xacThucOTP(maOTP),
            ),
            SizedBox(height: 32),

            if (dangXacThuc) CircularProgressIndicator(color: Colors.teal),

            SizedBox(height: 16),
            TextButton.icon(
              onPressed: guiLaiOTP,
              icon: Icon(Icons.refresh, color: Colors.teal),
              label: Text('Gửi lại mã OTP',
                  style: TextStyle(color: Colors.teal)),
            ),
          ],
        ),
      ),
    );
  }
}
