import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:badges/badges.dart' as badges;
import '../controller/home_controller.dart';
import '../controller/favorite_controller.dart';
import '../controller/auth_controller.dart';
import '../model/city_model.dart';
import 'favorite_page.dart';
import 'city_detail_page.dart';
import 'admin/manage_city_page.dart';
import 'login_page.dart';

class HomePage extends StatelessWidget {
  HomePage({super.key});

  // Dùng lazy init — chỉ tạo 1 lần, không tạo lại mỗi lần build
  final homeCtrl = Get.put(HomeController());
  final favCtrl = Get.put(FavoriteController());

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      // ── Drawer ──────────────────────────────────────────────
      drawer: GetBuilder<AuthController>(
        builder: (authCtrl) {
          final email = authCtrl.email;
          final loggedIn = email != null;

          return Drawer(
            child: Column(
              children: [
                // Header: avatar + tên tài khoản
                UserAccountsDrawerHeader(
                  decoration: BoxDecoration(color: Colors.teal),
                  accountName: Text(
                    loggedIn ? (authCtrl.tenHienThi) : 'Khách',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  accountEmail: Text(email ?? 'Chưa đăng nhập'),
                  currentAccountPicture: CircleAvatar(
                    backgroundColor: Colors.white,
                    child: Icon(
                      loggedIn ? Icons.person : Icons.person_outline,
                      color: Colors.teal,
                      size: 36,
                    ),
                  ),
                ),

                // Nút Quản lý (chỉ admin)
                if (authCtrl.laAdmin)
                  ListTile(
                    leading: Icon(Icons.admin_panel_settings, color: Colors.teal),
                    title: Text('Quản lý thành phố'),
                    onTap: () {
                      Get.back(); // đóng drawer
                      Get.to(() => ManageCityPage());
                    },
                  ),

                if (authCtrl.laAdmin) Divider(),

                // Nút Đăng nhập (khi chưa đăng nhập)
                if (!loggedIn)
                  ListTile(
                    leading: Icon(Icons.login, color: Colors.teal),
                    title: Text('Đăng nhập'),
                    onTap: () {
                      Get.back();
                      Get.to(() => LoginPage());
                    },
                  ),

                // Nút Đăng xuất (khi đã đăng nhập)
                if (loggedIn)
                  ListTile(
                    leading: Icon(Icons.logout, color: Colors.red),
                    title: Text('Đăng xuất',
                        style: TextStyle(color: Colors.red)),
                    onTap: () {
                      Get.back(); // đóng drawer
                      Get.defaultDialog(
                        title: 'Đăng xuất',
                        middleText: 'Bạn có chắc muốn đăng xuất?',
                        textConfirm: 'Đồng ý',
                        textCancel: 'Hủy',
                        confirmTextColor: Colors.white,
                        buttonColor: Colors.teal,
                        onConfirm: () {
                          Get.back();
                          homeCtrl.dangXuat();
                        },
                      );
                    },
                  ),

                Spacer(),
                Divider(),
                Padding(
                  padding: EdgeInsets.only(bottom: 12),
                  child: Text('Travel Vietnam 🇻🇳',
                      style: TextStyle(color: Colors.grey, fontSize: 12)),
                ),
              ],
            ),
          );
        },
      ),

      // ── AppBar ───────────────────────────────────────────────
      appBar: AppBar(
        backgroundColor: Colors.teal,
        foregroundColor: Colors.white,
        title: Text('Travel Vietnam 🇻🇳',
            style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          // chỉ giữ lại icon yêu thích
          GetBuilder<FavoriteController>(
            builder: (ctrl) {
              return badges.Badge(
                showBadge: ctrl.danhSachYeuThich.isNotEmpty,
                badgeContent: Text(
                  '${ctrl.danhSachYeuThich.length}',
                  style: TextStyle(color: Colors.white, fontSize: 10),
                ),
                child: IconButton(
                  icon: Icon(Icons.favorite_border),
                  onPressed: () => Get.to(() => FavoritePage()),
                ),
              );
            },
          ),
        ],
      ),

      body: Column(
        children: [
          // thanh tìm kiếm
          Container(
            color: Colors.teal,
            padding: EdgeInsets.fromLTRB(12, 0, 12, 16),
            child: TextField(
              onChanged: (val) => homeCtrl.timKiem(val),
              decoration: InputDecoration(
                hintText: 'Tìm thành phố...',
                prefixIcon: Icon(Icons.search),
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(25),
                  borderSide: BorderSide.none,
                ),
                contentPadding: EdgeInsets.symmetric(vertical: 0),
              ),
            ),
          ),

          // danh sách thành phố
          Expanded(
            child: GetBuilder<HomeController>(
              builder: (ctrl) {
                // đang tải
                if (ctrl.dangTai) {
                  return Center(child: CircularProgressIndicator());
                }
                // không có dữ liệu
                if (ctrl.ketQuaTimKiem.isEmpty) {
                  return Center(child: Text('Không tìm thấy kết quả'));
                }
                // hiển thị grid
                return GridView.builder(
                  padding: EdgeInsets.all(12),
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 12,
                    childAspectRatio: 0.85,
                  ),
                  itemCount: ctrl.ketQuaTimKiem.length,
                  itemBuilder: (context, index) {
                    return _CardThanhPho(city: ctrl.ketQuaTimKiem[index]);
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

// widget card từng thành phố
class _CardThanhPho extends StatelessWidget {
  final CityModel city;
  const _CardThanhPho({required this.city});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        // truyền object city sang trang chi tiết
        Get.to(() => CityDetailPage(), arguments: city);
      },
      child: Card(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        elevation: 3,
        clipBehavior: Clip.antiAlias,
        child: Stack(
          fit: StackFit.expand,
          children: [
            // ảnh thành phố
            city.imageUrl != null
                ? Image.network(city.imageUrl!, fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) =>
                        Container(color: Colors.grey[200]))
                : Container(color: Colors.grey[200]),

            // gradient + tên
            Positioned(
              bottom: 0, left: 0, right: 0,
              child: Container(
                padding: EdgeInsets.all(8),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Colors.transparent, Colors.black54],
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(city.name,
                        style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 15)),
                    if (city.moTa != null)
                      Text(city.moTa!,
                          style: TextStyle(color: Colors.white70, fontSize: 11),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
