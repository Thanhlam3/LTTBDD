import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import '../controller/favorite_controller.dart';
import '../model/place_model.dart';
import 'place_detail_page.dart';

class FavoritePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final ctrl = Get.find<FavoriteController>();

    return Scaffold(
      appBar: AppBar(
        title: Text('Địa điểm yêu thích'),
        backgroundColor: Colors.teal,
        foregroundColor: Colors.white,
      ),
      body: GetBuilder<FavoriteController>(
        builder: (ctrl) {
          // đang tải
          if (ctrl.dangTai) {
            return Center(child: CircularProgressIndicator());
          }

          // chưa có yêu thích nào
          if (ctrl.danhSachYeuThich.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.favorite_border, size: 70, color: Colors.grey[300]),
                  SizedBox(height: 12),
                  Text('Chưa có địa điểm yêu thích',
                      style: TextStyle(color: Colors.grey, fontSize: 15)),
                  SizedBox(height: 8),
                  Text('Nhấn ♡ ở trang chi tiết để lưu',
                      style: TextStyle(color: Colors.grey[400], fontSize: 13)),
                ],
              ),
            );
          }

          return ListView.builder(
            padding: EdgeInsets.all(12),
            itemCount: ctrl.danhSachYeuThich.length,
            itemBuilder: (context, index) {
              PlaceModel place = ctrl.danhSachYeuThich[index];

              // Slidable: vuốt trái để xóa
              return Slidable(
                key: ValueKey(place.id),
                endActionPane: ActionPane(
                  motion: ScrollMotion(),
                  children: [
                    SlidableAction(
                      onPressed: (_) => ctrl.xoaYeuThich(place.id),
                      backgroundColor: Colors.red,
                      foregroundColor: Colors.white,
                      icon: Icons.delete,
                      label: 'Xóa',
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ],
                ),
                child: Card(
                  margin: EdgeInsets.only(bottom: 12),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12)),
                  elevation: 2,
                  child: InkWell(
                    borderRadius: BorderRadius.circular(12),
                    onTap: () => Get.to(() => PlaceDetailPage(), arguments: place),
                    child: Row(
                      children: [
                        // ảnh
                        ClipRRect(
                          borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(12),
                            bottomLeft: Radius.circular(12),
                          ),
                          child: place.imageUrl != null
                              ? Image.network(
                                  place.imageUrl!,
                                  width: 100,
                                  height: 90,
                                  fit: BoxFit.cover,
                                  errorBuilder: (_, __, ___) => Container(
                                      width: 100,
                                      height: 90,
                                      color: Colors.grey[200]),
                                )
                              : Container(
                                  width: 100,
                                  height: 90,
                                  color: Colors.grey[200]),
                        ),

                        // thông tin
                        Expanded(
                          child: Padding(
                            padding: EdgeInsets.all(10),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(place.name,
                                    style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 14),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis),
                                SizedBox(height: 4),
                                // loại địa điểm
                                Text(place.getTenLoai(),
                                    style: TextStyle(
                                        color: Colors.teal, fontSize: 12)),
                                SizedBox(height: 4),
                                if (place.diaChi != null)
                                  Row(
                                    children: [
                                      Icon(Icons.location_on,
                                          size: 12, color: Colors.grey),
                                      SizedBox(width: 2),
                                      Expanded(
                                        child: Text(place.diaChi!,
                                            style: TextStyle(
                                                fontSize: 11,
                                                color: Colors.grey),
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis),
                                      ),
                                    ],
                                  ),
                              ],
                            ),
                          ),
                        ),

                        // icon gợi ý vuốt
                        Padding(
                          padding: EdgeInsets.only(right: 8),
                          child: Icon(Icons.swipe_left,
                              size: 16, color: Colors.grey[400]),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
