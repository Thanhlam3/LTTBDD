import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../controller/favorite_controller.dart';
import '../controller/auth_controller.dart';

import '../model/place_model.dart';
import 'admin/form_place_page.dart';

class PlaceDetailPage extends StatelessWidget {
  @override
  final supabase = Supabase.instance.client;

  Widget build(BuildContext context) {
    // nhận place từ arguments
    final PlaceModel place = Get.arguments;
    final favCtrl = Get.find<FavoriteController>();

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          // ảnh bìa + nút back
          SliverAppBar(
            expandedHeight: 260,
            pinned: true,
            backgroundColor: Colors.teal,
            foregroundColor: Colors.white,
            title: Text(place.name,
                maxLines: 1, overflow: TextOverflow.ellipsis),
            // actions: nút sửa (admin) + nút yêu thích (user đã đăng nhập)
            actions: [
              // nút sửa — chỉ admin
              GetBuilder<AuthController>(
                builder: (authCtrl) {
                  if (!authCtrl.laAdmin) return SizedBox.shrink();
                  return IconButton(
                    icon: Icon(Icons.edit),
                    tooltip: 'Sửa địa điểm',
                    onPressed: () => Get.to(
                      () => FormPlacePage(
                        cityId: place.cityId,
                        place: place,
                      ),
                    ),
                  );
                },
              ),
              // nút yêu thích — chỉ user đã đăng nhập
              if (supabase.auth.currentUser != null)
                GetBuilder<FavoriteController>(
                  builder: (ctrl) {
                    bool daThich = ctrl.daYeuThich(place.id);
                    return IconButton(
                      icon: Icon(
                        daThich ? Icons.favorite : Icons.favorite_border,
                        color: daThich ? Colors.red : Colors.white,
                      ),
                      onPressed: () => ctrl.toggleYeuThich(place),
                    );
                  },
                ),
            ],
            flexibleSpace: FlexibleSpaceBar(
              background: place.imageUrl != null
                  ? Image.network(place.imageUrl!, fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) =>
                          Container(color: Colors.teal))
                  : Container(color: Colors.teal),
            ),
          ),

          // nội dung chi tiết
          SliverToBoxAdapter(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // tên + loại
                  Text(place.name,
                      style: TextStyle(
                          fontSize: 22, fontWeight: FontWeight.bold)),
                  SizedBox(height: 6),
                  Container(
                    padding:
                        EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: Colors.teal.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(place.getTenLoai(),
                        style: TextStyle(
                            color: Colors.teal, fontSize: 12)),
                  ),
                  SizedBox(height: 12),

                  // rating hiển thị bằng sao (flutter_rating_bar)
                  Row(
                    children: [
                      RatingBarIndicator(
                        rating: place.rating,
                        itemBuilder: (context, _) =>
                            Icon(Icons.star, color: Colors.amber),
                        itemCount: 5,
                        itemSize: 20,
                      ),
                      SizedBox(width: 8),
                      Text('${place.rating}/5',
                          style: TextStyle(color: Colors.grey)),
                    ],
                  ),
                  SizedBox(height: 16),

                  // địa chỉ
                  if (place.diaChi != null) ...[
                    Row(
                      children: [
                        Icon(Icons.location_on, color: Colors.teal, size: 18),
                        SizedBox(width: 6),
                        Expanded(
                          child: Text(place.diaChi!,
                              style: TextStyle(fontSize: 14)),
                        ),
                      ],
                    ),
                    SizedBox(height: 16),
                  ],

                  Divider(),
                  SizedBox(height: 12),

                  // mô tả
                  Text('Giới thiệu',
                      style: TextStyle(
                          fontSize: 16, fontWeight: FontWeight.bold)),
                  SizedBox(height: 8),
                  Text(
                    place.moTa ?? 'Chưa có mô tả cho địa điểm này.',
                    style: TextStyle(
                        fontSize: 14,
                        color: Colors.grey[700],
                        height: 1.6),
                  ),
                  SizedBox(height: 24),

                  // nút thêm yêu thích
                  GetBuilder<FavoriteController>(
                    builder: (ctrl) {
                      bool daThich = ctrl.daYeuThich(place.id);
                      return SizedBox(
                        width: double.infinity,
                        height: 50,
                        child: ElevatedButton.icon(
                          onPressed: () => ctrl.toggleYeuThich(place),
                          icon: Icon(
                            daThich
                                ? Icons.favorite
                                : Icons.favorite_border,
                            color: Colors.white,
                          ),
                          label: Text(
                            daThich
                                ? 'Đã lưu yêu thích'
                                : 'Thêm vào yêu thích',
                            style: TextStyle(
                                fontSize: 15, color: Colors.white),
                          ),
                          style: ElevatedButton.styleFrom(
                            backgroundColor:
                                daThich ? Colors.red : Colors.teal,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10)),
                          ),
                        ),
                      );
                    },
                  ),
                  SizedBox(height: 16),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
