import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controller/place_controller.dart';
import '../controller/auth_controller.dart';
import '../model/city_model.dart';
import '../model/place_model.dart';
import 'admin/manage_city_page.dart';
import 'place_detail_page.dart';

class CityDetailPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // nhận city từ arguments
    final CityModel city = Get.arguments;
    final ctrl = Get.put(PlaceController());

    // lấy địa điểm của thành phố này
    ctrl.layDiaDiem(city.id);

    return DefaultTabController(
      length: 3,
      child: Scaffold(
        body: NestedScrollView(
          headerSliverBuilder: (context, innerBoxIsScrolled) {
            return [
              SliverAppBar(
                expandedHeight: 220,
                pinned: true,
                backgroundColor: Colors.teal,
                foregroundColor: Colors.white,
                title: Text(city.name),
                // nút quản lý địa điểm — chỉ admin mới thấy
                actions: [
                  GetBuilder<AuthController>(
                    builder: (authCtrl) {
                      if (!authCtrl.laAdmin) return SizedBox.shrink();
                      return IconButton(
                        icon: Icon(Icons.edit_note),
                        tooltip: 'Quản lý địa điểm',
                        onPressed: () => Get.to(
                          () => ManagePlacePage(city: city),
                        ),
                      );
                    },
                  ),
                ],
                // ảnh bìa thành phố
                flexibleSpace: FlexibleSpaceBar(
                  background: city.imageUrl != null
                      ? Image.network(city.imageUrl!, fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) =>
                              Container(color: Colors.teal))
                      : Container(color: Colors.teal),
                ),
                // tab bar ở dưới ảnh
                bottom: TabBar(
                  indicatorColor: Colors.white,
                  labelColor: Colors.white,
                  unselectedLabelColor: Colors.white60,
                  onTap: (index) {
                    // chuyển tab → lọc lại danh sách
                    List<String> loai = ['tham_quan', 'quan_an', 'khach_san'];
                    ctrl.locTheoLoai(loai[index]);
                  },
                  tabs: [
                    Tab(icon: Icon(Icons.museum), text: 'Tham quan'),
                    Tab(icon: Icon(Icons.restaurant), text: 'Quán ăn'),
                    Tab(icon: Icon(Icons.hotel), text: 'Khách sạn'),
                  ],
                ),
              ),
            ];
          },

          // nội dung tab
          body: TabBarView(
            children: [
              _DanhSachDiaDiem(),
              _DanhSachDiaDiem(),
              _DanhSachDiaDiem(),
            ],
          ),
        ),
      ),
    );
  }
}

// widget danh sách địa điểm theo tab
class _DanhSachDiaDiem extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return GetBuilder<PlaceController>(
      builder: (ctrl) {
        // đang tải
        if (ctrl.dangTai) {
          return Center(child: CircularProgressIndicator());
        }
        // không có địa điểm
        if (ctrl.tabHienTai.isEmpty) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.search_off, size: 60, color: Colors.grey[300]),
                SizedBox(height: 8),
                Text('Chưa có địa điểm nào',
                    style: TextStyle(color: Colors.grey)),
              ],
            ),
          );
        }
        // danh sách
        return ListView.builder(
          padding: EdgeInsets.all(12),
          itemCount: ctrl.tabHienTai.length,
          itemBuilder: (context, index) {
            return _CardDiaDiem(place: ctrl.tabHienTai[index]);
          },
        );
      },
    );
  }
}

// card từng địa điểm
class _CardDiaDiem extends StatelessWidget {
  final PlaceModel place;
  const _CardDiaDiem({required this.place});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 2,
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () => Get.to(() => PlaceDetailPage(), arguments: place),
        child: Row(
          children: [
            // ảnh bên trái
            ClipRRect(
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(12),
                bottomLeft: Radius.circular(12),
              ),
              child: place.imageUrl != null
                  ? Image.network(place.imageUrl!,
                      width: 110, height: 100, fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) =>
                          Container(width: 110, height: 100, color: Colors.grey[200]))
                  : Container(width: 110, height: 100, color: Colors.grey[200]),
            ),

            // thông tin bên phải
            Expanded(
              child: Padding(
                padding: EdgeInsets.all(10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(place.name,
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 15),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis),
                    SizedBox(height: 4),
                    if (place.diaChi != null)
                      Row(
                        children: [
                          Icon(Icons.location_on, size: 13, color: Colors.grey),
                          SizedBox(width: 2),
                          Expanded(
                            child: Text(place.diaChi!,
                                style: TextStyle(
                                    fontSize: 12, color: Colors.grey),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis),
                          ),
                        ],
                      ),
                    SizedBox(height: 4),
                    // hiển thị rating bằng sao
                    Row(
                      children: [
                        Icon(Icons.star, size: 14, color: Colors.amber),
                        SizedBox(width: 2),
                        Text('${place.rating}',
                            style: TextStyle(fontSize: 12)),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            Icon(Icons.chevron_right, color: Colors.grey),
            SizedBox(width: 4),
          ],
        ),
      ),
    );
  }
}
