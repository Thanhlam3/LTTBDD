import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:phamlam/travel_recommend_app/travel_recommend_app/controller/admin_controller.dart';

import '../../model/city_model.dart';
import '../../model/place_model.dart';
import 'form_city_page.dart';
import 'form_place_page.dart';

class ManageCityPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final ctrl = Get.find<AdminController>();
    ctrl.layThanhPho();

    return Scaffold(
      appBar: AppBar(
        title: Text('Quản lý thành phố'),
        backgroundColor: Colors.teal,
        foregroundColor: Colors.white,
      ),
      // nút thêm mới ở góc dưới phải
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: Colors.teal,
        icon: Icon(Icons.add, color: Colors.white),
        label: Text('Thêm thành phố', style: TextStyle(color: Colors.white)),
        onPressed: () {
          // mở trang form, không truyền city = thêm mới
          Get.to(() => FormCityPage(city: null));
        },
      ),
      body: GetBuilder<AdminController>(
        builder: (ctrl) {
          if (ctrl.dangTai) {
            return Center(child: CircularProgressIndicator());
          }
          if (ctrl.danhSachThanhPho.isEmpty) {
            return Center(child: Text('Chưa có thành phố nào'));
          }

          return ListView.builder(
            padding: EdgeInsets.fromLTRB(12, 12, 12, 80),
            itemCount: ctrl.danhSachThanhPho.length,
            itemBuilder: (context, index) {
              CityModel city = ctrl.danhSachThanhPho[index];
              return Card(
                margin: EdgeInsets.only(bottom: 10),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
                elevation: 2,
                child: ListTile(
                  contentPadding: EdgeInsets.all(10),
                  // ảnh nhỏ bên trái
                  leading: ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: city.imageUrl != null
                        ? Image.network(city.imageUrl!,
                            width: 60, height: 60, fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) =>
                                _iconPlaceholder())
                        : _iconPlaceholder(),
                  ),
                  title: Text(city.name,
                      style: TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Text(
                    city.moTa ?? 'Chưa có mô tả',
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                  // nút sửa + xóa
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      // nút sửa
                      IconButton(
                        icon: Icon(Icons.edit, color: Colors.blue),
                        onPressed: () {
                          // truyền city vào form = chế độ sửa
                          Get.to(() => FormCityPage(city: city));
                        },
                      ),
                      // nút xóa
                      IconButton(
                        icon: Icon(Icons.delete, color: Colors.red),
                        onPressed: () => _hienDialogXoa(ctrl, city),
                      ),
                    ],
                  ),
                  // nhấn vào → quản lý địa điểm của thành phố này
                  onTap: () => Get.to(
                    () => ManagePlacePage(city: city),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }

  Widget _iconPlaceholder() {
    return Container(
      width: 60,
      height: 60,
      color: Colors.grey[200],
      child: Icon(Icons.location_city, color: Colors.grey),
    );
  }

  void _hienDialogXoa(AdminController ctrl, CityModel city) {
    Get.defaultDialog(
      title: 'Xóa thành phố',
      middleText:
          'Xóa "${city.name}" sẽ xóa luôn tất cả địa điểm bên trong!\nBạn có chắc không?',
      textConfirm: 'Xóa',
      textCancel: 'Hủy',
      confirmTextColor: Colors.white,
      buttonColor: Colors.red,
      onConfirm: () {
        Get.back();
        ctrl.xoaThanhPho(city.id, city.name);
      },
    );
  }
}


// =============================================
// TRANG QUẢN LÝ ĐỊA ĐIỂM THEO THÀNH PHỐ
// =============================================


class ManagePlacePage extends StatelessWidget {
  final CityModel city;
  ManagePlacePage({required this.city});

  @override
  Widget build(BuildContext context) {
    final ctrl = Get.find<AdminController>();
    ctrl.layDiaDiemTheoThanhPho(city.id);

    return Scaffold(
      appBar: AppBar(
        title: Text('Địa điểm - ${city.name}'),
        backgroundColor: Colors.teal,
        foregroundColor: Colors.white,
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: Colors.teal,
        icon: Icon(Icons.add, color: Colors.white),
        label: Text('Thêm địa điểm', style: TextStyle(color: Colors.white)),
        onPressed: () {
          Get.to(() => FormPlacePage(cityId: city.id, place: null));
        },
      ),
      body: GetBuilder<AdminController>(
        builder: (ctrl) {
          if (ctrl.dangTai) {
            return Center(child: CircularProgressIndicator());
          }
          if (ctrl.danhSachDiaDiem.isEmpty) {
            return Center(child: Text('Chưa có địa điểm nào'));
          }

          return ListView.builder(
            padding: EdgeInsets.fromLTRB(12, 12, 12, 80),
            itemCount: ctrl.danhSachDiaDiem.length,
            itemBuilder: (context, index) {
              PlaceModel place = ctrl.danhSachDiaDiem[index];
              return Card(
                margin: EdgeInsets.only(bottom: 10),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
                elevation: 2,
                child: ListTile(
                  contentPadding: EdgeInsets.all(10),
                  leading: ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: place.imageUrl != null
                        ? Image.network(place.imageUrl!,
                            width: 60, height: 60, fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) =>
                                _iconPlaceholder())
                        : _iconPlaceholder(),
                  ),
                  title: Text(place.name,
                      style: TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // badge loại
                      Container(
                        margin: EdgeInsets.only(top: 2, bottom: 2),
                        padding: EdgeInsets.symmetric(
                            horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: Colors.teal.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text(place.getTenLoai(),
                            style: TextStyle(
                                color: Colors.teal, fontSize: 11)),
                      ),
                      Text(place.diaChi ?? '',
                          style:
                              TextStyle(fontSize: 11, color: Colors.grey),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis),
                    ],
                  ),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: Icon(Icons.edit, color: Colors.blue),
                        onPressed: () => Get.to(
                            () => FormPlacePage(cityId: city.id, place: place)),
                      ),
                      IconButton(
                        icon: Icon(Icons.delete, color: Colors.red),
                        onPressed: () =>
                            _hienDialogXoa(ctrl, place),
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }

  Widget _iconPlaceholder() {
    return Container(
      width: 60,
      height: 60,
      color: Colors.grey[200],
      child: Icon(Icons.place, color: Colors.grey),
    );
  }

  void _hienDialogXoa(AdminController ctrl, PlaceModel place) {
    Get.defaultDialog(
      title: 'Xóa địa điểm',
      middleText: 'Xóa "${place.name}"?\nHành động này không thể hoàn tác.',
      textConfirm: 'Xóa',
      textCancel: 'Hủy',
      confirmTextColor: Colors.white,
      buttonColor: Colors.red,
      onConfirm: () {
        Get.back();
        ctrl.xoaDiaDiem(place.id, city.id, place.name);
      },
    );
  }
}
