import 'dart:io';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../controller/admin_controller.dart';
import '../../model/city_model.dart';

class FormCityPage extends StatefulWidget {
  final CityModel? city; // null = thêm mới, có giá trị = sửa
  FormCityPage({required this.city});

  @override
  State<FormCityPage> createState() => _FormCityPageState();
}

class _FormCityPageState extends State<FormCityPage> {
  final nameController = TextEditingController();
  final moTaController = TextEditingController();
  File? anhDaChon; // ảnh mới chọn từ thư viện

  bool get laSua => widget.city != null; // kiểm tra đang thêm hay sửa

  @override
  void initState() {
    super.initState();
    // nếu đang sửa thì điền sẵn dữ liệu cũ vào form
    if (laSua) {
      nameController.text = widget.city!.name;
      moTaController.text = widget.city!.moTa ?? '';
    }
  }

  @override
  Widget build(BuildContext context) {
    final ctrl = Get.find<AdminController>();

    return Scaffold(
      appBar: AppBar(
        title: Text(laSua ? 'Sửa thành phố' : 'Thêm thành phố'),
        backgroundColor: Colors.teal,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ===== CHỌN ẢNH =====
            Center(
              child: GestureDetector(
                onTap: () async {
                  // gọi hàm chọn ảnh từ thư viện
                  File? file = await ctrl.chonAnh();
                  if (file != null) setState(() => anhDaChon = file);
                },
                child: Container(
                  width: double.infinity,
                  height: 180,
                  decoration: BoxDecoration(
                    color: Colors.grey[100],
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.grey[300]!),
                  ),
                  child: _hienThiAnh(),
                ),
              ),
            ),
            SizedBox(height: 8),
            Center(
              child: Text('Nhấn để chọn ảnh',
                  style: TextStyle(color: Colors.grey, fontSize: 12)),
            ),
            SizedBox(height: 20),

            // ===== TÊN THÀNH PHỐ =====
            Text('Tên thành phố *',
                style: TextStyle(fontWeight: FontWeight.bold)),
            SizedBox(height: 6),
            TextField(
              controller: nameController,
              decoration: InputDecoration(
                hintText: 'Ví dụ: Đà Nẵng',
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10)),
              ),
            ),
            SizedBox(height: 16),

            // ===== MÔ TẢ =====
            Text('Mô tả', style: TextStyle(fontWeight: FontWeight.bold)),
            SizedBox(height: 6),
            TextField(
              controller: moTaController,
              maxLines: 3,
              decoration: InputDecoration(
                hintText: 'Mô tả ngắn về thành phố...',
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10)),
              ),
            ),
            SizedBox(height: 32),

            // ===== NÚT LƯU =====
            GetBuilder<AdminController>(
              builder: (ctrl) {
                return SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: ElevatedButton(
                    onPressed: ctrl.dangTai ? null : () => _luuDuLieu(ctrl),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.teal,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10)),
                    ),
                    child: ctrl.dangTai
                        ? CircularProgressIndicator(color: Colors.white)
                        : Text(
                            laSua ? 'Cập nhật' : 'Thêm mới',
                            style: TextStyle(
                                fontSize: 16, color: Colors.white),
                          ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  // hiển thị ảnh: ưu tiên ảnh mới chọn, rồi đến ảnh cũ, rồi icon mặc định
  Widget _hienThiAnh() {
    if (anhDaChon != null) {
      return ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: Image.file(anhDaChon!, fit: BoxFit.cover),
      );
    }
    if (laSua && widget.city!.imageUrl != null) {
      return ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: Image.network(widget.city!.imageUrl!, fit: BoxFit.cover),
      );
    }
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(Icons.add_photo_alternate, size: 48, color: Colors.grey),
        SizedBox(height: 8),
        Text('Chọn ảnh', style: TextStyle(color: Colors.grey)),
      ],
    );
  }

  void _luuDuLieu(AdminController ctrl) {
    String name = nameController.text.trim();
    String moTa = moTaController.text.trim();

    if (name.isEmpty) {
      Get.snackbar('Thiếu thông tin', 'Vui lòng nhập tên thành phố',
          backgroundColor: Colors.orange, colorText: Colors.white);
      return;
    }

    if (laSua) {
      // cập nhật
      ctrl.suaThanhPho(
          widget.city!.id, name, moTa, anhDaChon, widget.city!.imageUrl);
    } else {
      // thêm mới
      ctrl.themThanhPho(name, moTa, anhDaChon);
    }
  }
}
