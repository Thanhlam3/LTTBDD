import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:get/get.dart';
import '../../controller/admin_controller.dart';
import '../../model/place_model.dart';

class FormPlacePage extends StatefulWidget {
  final int cityId;
  final PlaceModel? place; // null = thêm mới, có giá trị = sửa
  FormPlacePage({required this.cityId, required this.place});

  @override
  State<FormPlacePage> createState() => _FormPlacePageState();
}

class _FormPlacePageState extends State<FormPlacePage> {
  final nameController    = TextEditingController();
  final diaChiController  = TextEditingController();
  final moTaController    = TextEditingController();

  String loaiDangChon = 'tham_quan'; // loại mặc định
  double ratingDangChon = 4.0;
  File? anhDaChon;

  bool get laSua => widget.place != null;

  // danh sách loại địa điểm
  final danhSachLoai = [
    {'value': 'tham_quan', 'label': 'Tham quan', 'icon': Icons.museum},
    {'value': 'quan_an',   'label': 'Quán ăn',   'icon': Icons.restaurant},
    {'value': 'khach_san', 'label': 'Khách sạn', 'icon': Icons.hotel},
  ];

  @override
  void initState() {
    super.initState();
    // điền sẵn dữ liệu nếu đang sửa
    if (laSua) {
      nameController.text   = widget.place!.name;
      diaChiController.text = widget.place!.diaChi ?? '';
      moTaController.text   = widget.place!.moTa ?? '';
      loaiDangChon          = widget.place!.loai;
      ratingDangChon        = widget.place!.rating;
    }
  }

  @override
  Widget build(BuildContext context) {
    final ctrl = Get.find<AdminController>();

    return Scaffold(
      appBar: AppBar(
        title: Text(laSua ? 'Sửa địa điểm' : 'Thêm địa điểm'),
        backgroundColor: Colors.teal,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            // ===== CHỌN ẢNH =====
            GestureDetector(
              onTap: () async {
                File? file = await ctrl.chonAnh();
                if (file != null) setState(() => anhDaChon = file);
              },
              child: Container(
                width: double.infinity,
                height: 180,
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.grey[300]!),
                ),
                child: _hienThiAnh(),
              ),
            ),
            Center(
              child: Padding(
                padding: EdgeInsets.only(top: 6, bottom: 16),
                child: Text('Nhấn để chọn ảnh',
                    style: TextStyle(color: Colors.grey, fontSize: 12)),
              ),
            ),

            // ===== TÊN ĐỊA ĐIỂM =====
            Text('Tên địa điểm *',
                style: TextStyle(fontWeight: FontWeight.bold)),
            SizedBox(height: 6),
            TextField(
              controller: nameController,
              decoration: InputDecoration(
                hintText: 'Ví dụ: Bà Nà Hills',
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10)),
              ),
            ),
            SizedBox(height: 16),

            // ===== LOẠI ĐỊA ĐIỂM =====
            Text('Loại địa điểm *',
                style: TextStyle(fontWeight: FontWeight.bold)),
            SizedBox(height: 8),
            Row(
              children: danhSachLoai.map((loai) {
                bool daDuocChon = loaiDangChon == loai['value'];
                return Expanded(
                  child: GestureDetector(
                    onTap: () =>
                        setState(() => loaiDangChon = loai['value'] as String),
                    child: Container(
                      margin: EdgeInsets.only(right: 6),
                      padding: EdgeInsets.symmetric(vertical: 10),
                      decoration: BoxDecoration(
                        color: daDuocChon
                            ? Colors.teal
                            : Colors.grey[100],
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(
                          color: daDuocChon
                              ? Colors.teal
                              : Colors.grey[300]!,
                        ),
                      ),
                      child: Column(
                        children: [
                          Icon(
                            loai['icon'] as IconData,
                            color: daDuocChon ? Colors.white : Colors.grey,
                            size: 22,
                          ),
                          SizedBox(height: 4),
                          Text(
                            loai['label'] as String,
                            style: TextStyle(
                              color:
                                  daDuocChon ? Colors.white : Colors.grey,
                              fontSize: 11,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
            SizedBox(height: 16),

            // ===== ĐỊA CHỈ =====
            Text('Địa chỉ', style: TextStyle(fontWeight: FontWeight.bold)),
            SizedBox(height: 6),
            TextField(
              controller: diaChiController,
              decoration: InputDecoration(
                hintText: 'Ví dụ: 123 Nguyễn Văn Linh, Đà Nẵng',
                prefixIcon: Icon(Icons.location_on),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10)),
              ),
            ),
            SizedBox(height: 16),

            // ===== ĐÁNH GIÁ =====
            Text('Đánh giá', style: TextStyle(fontWeight: FontWeight.bold)),
            SizedBox(height: 8),
            Row(
              children: [
                // thanh chọn sao (flutter_rating_bar)
                RatingBar.builder(
                  initialRating: ratingDangChon,
                  minRating: 1,
                  allowHalfRating: true,
                  itemCount: 5,
                  itemSize: 32,
                  itemBuilder: (context, _) =>
                      Icon(Icons.star, color: Colors.amber),
                  onRatingUpdate: (r) =>
                      setState(() => ratingDangChon = r),
                ),
                SizedBox(width: 12),
                Text('$ratingDangChon / 5',
                    style: TextStyle(color: Colors.grey)),
              ],
            ),
            SizedBox(height: 16),

            // ===== MÔ TẢ =====
            Text('Mô tả', style: TextStyle(fontWeight: FontWeight.bold)),
            SizedBox(height: 6),
            TextField(
              controller: moTaController,
              maxLines: 4,
              decoration: InputDecoration(
                hintText: 'Mô tả chi tiết về địa điểm...',
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10)),
              ),
            ),
            SizedBox(height: 32),

            // ===== NÚT LƯU =====
            GetBuilder<AdminController>(
              builder: (ctrl) {
                return SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: ElevatedButton(
                    onPressed:
                        ctrl.dangTai ? null : () => _luuDuLieu(ctrl),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.teal,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10)),
                    ),
                    child: ctrl.dangTai
                        ? CircularProgressIndicator(color: Colors.white)
                        : Text(
                            laSua ? 'Cập nhật' : 'Thêm mới',
                            style: TextStyle(
                                fontSize: 16, color: Colors.white),
                          ),
                  ),
                );
              },
            ),
            SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _hienThiAnh() {
    if (anhDaChon != null) {
      return ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: Image.file(anhDaChon!, fit: BoxFit.cover),
      );
    }
    if (laSua && widget.place!.imageUrl != null) {
      return ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: Image.network(widget.place!.imageUrl!, fit: BoxFit.cover),
      );
    }
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(Icons.add_photo_alternate, size: 48, color: Colors.grey),
        SizedBox(height: 8),
        Text('Chọn ảnh', style: TextStyle(color: Colors.grey)),
      ],
    );
  }

  void _luuDuLieu(AdminController ctrl) {
    String name   = nameController.text.trim();
    String diaChi = diaChiController.text.trim();
    String moTa   = moTaController.text.trim();

    if (name.isEmpty) {
      Get.snackbar('Thiếu thông tin', 'Vui lòng nhập tên địa điểm',
          backgroundColor: Colors.orange, colorText: Colors.white);
      return;
    }

    if (laSua) {
      ctrl.suaDiaDiem(widget.place!.id, widget.cityId, name, loaiDangChon,
          diaChi, moTa, ratingDangChon, anhDaChon, widget.place!.imageUrl);
    } else {
      ctrl.themDiaDiem(widget.cityId, name, loaiDangChon, diaChi, moTa,
          ratingDangChon, anhDaChon);
    }
  }
}
