import 'dart:io';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import '../main_travel.dart';
import '../model/city_model.dart';
import '../model/place_model.dart';

class AdminController extends GetxController {
  List<CityModel> danhSachThanhPho = [];
  List<PlaceModel> danhSachDiaDiem = [];
  bool dangTai = false;

  final picker = ImagePicker();

  // ===================== THÀNH PHỐ =====================

  void layThanhPho() async {
    dangTai = true;
    update();
    try {
      var data = await supabase.from('cities').select().order('name');
      danhSachThanhPho =
          (data as List).map((e) => CityModel.fromJson(e)).toList();
    } catch (e) {
      Get.snackbar('Lỗi', 'Không tải được danh sách');
    }
    dangTai = false;
    update();
  }

  // thêm thành phố mới
  void themThanhPho(String name, String moTa, File? anhFile) async {
    dangTai = true;
    update();
    try {
      String? imageUrl;

      // upload ảnh lên supabase storage nếu có chọn ảnh
      if (anhFile != null) {
        imageUrl = await _uploadAnh(anhFile, 'cities');
      }

      await supabase.from('cities').insert({
        'name': name,
        'description': moTa,
        'image_url': imageUrl,
      });

      Get.snackbar('Thành công', 'Đã thêm thành phố $name',
          backgroundColor: Get.theme.colorScheme.primary.withOpacity(0.8));
      layThanhPho(); // tải lại danh sách
      Get.back();   // đóng trang form
    } catch (e) {
      Get.snackbar('Lỗi', 'Thêm thất bại: $e');
    }
    dangTai = false;
    update();
  }

  // cập nhật thành phố
  void suaThanhPho(int id, String name, String moTa, File? anhFile,
      String? urlCu) async {
    dangTai = true;
    update();
    try {
      String? imageUrl = urlCu; // giữ ảnh cũ nếu không chọn ảnh mới

      if (anhFile != null) {
        imageUrl = await _uploadAnh(anhFile, 'cities');
      }

      await supabase.from('cities').update({
        'name': name,
        'description': moTa,
        'image_url': imageUrl,
      }).eq('id', id);

      Get.snackbar('Thành công', 'Đã cập nhật thành phố');
      layThanhPho();
      Get.back();
    } catch (e) {
      Get.snackbar('Lỗi', 'Cập nhật thất bại: $e');
    }
    dangTai = false;
    update();
  }

  // xóa thành phố
  void xoaThanhPho(int id, String name) async {
    try {
      await supabase.from('cities').delete().eq('id', id);
      Get.snackbar('Đã xóa', 'Đã xóa thành phố $name');
      layThanhPho();
    } catch (e) {
      Get.snackbar('Lỗi', 'Xóa thất bại: $e');
    }
  }

  // ===================== ĐỊA ĐIỂM =====================

  void layDiaDiemTheoThanhPho(int cityId) async {
    dangTai = true;
    update();
    try {
      var data = await supabase
          .from('places')
          .select()
          .eq('city_id', cityId)
          .order('name');
      danhSachDiaDiem =
          (data as List).map((e) => PlaceModel.fromJson(e)).toList();
    } catch (e) {
      Get.snackbar('Lỗi', 'Không tải được địa điểm');
    }
    dangTai = false;
    update();
  }

  // thêm địa điểm mới
  void themDiaDiem(int cityId, String name, String loai, String diaChi,
      String moTa, double rating, File? anhFile) async {
    dangTai = true;
    update();
    try {
      String? imageUrl;
      if (anhFile != null) {
        imageUrl = await _uploadAnh(anhFile, 'places');
      }

      await supabase.from('places').insert({
        'city_id': cityId,
        'name': name,
        'type': loai,
        'address': diaChi,
        'description': moTa,
        'rating': rating,
        'image_url': imageUrl,
      });

      Get.snackbar('Thành công', 'Đã thêm địa điểm $name');
      layDiaDiemTheoThanhPho(cityId);
      Get.back();
    } catch (e) {
      Get.snackbar('Lỗi', 'Thêm thất bại: $e');
    }
    dangTai = false;
    update();
  }

  // cập nhật địa điểm
  void suaDiaDiem(int id, int cityId, String name, String loai, String diaChi,
      String moTa, double rating, File? anhFile, String? urlCu) async {
    dangTai = true;
    update();
    try {
      String? imageUrl = urlCu;
      if (anhFile != null) {
        imageUrl = await _uploadAnh(anhFile, 'places');
      }

      await supabase.from('places').update({
        'name': name,
        'type': loai,
        'address': diaChi,
        'description': moTa,
        'rating': rating,
        'image_url': imageUrl,
      }).eq('id', id);

      Get.snackbar('Thành công', 'Đã cập nhật địa điểm');
      layDiaDiemTheoThanhPho(cityId);
      Get.back();
    } catch (e) {
      Get.snackbar('Lỗi', 'Cập nhật thất bại: $e');
    }
    dangTai = false;
    update();
  }

  // xóa địa điểm
  void xoaDiaDiem(int id, int cityId, String name) async {
    try {
      await supabase.from('places').delete().eq('id', id);
      Get.snackbar('Đã xóa', 'Đã xóa $name');
      layDiaDiemTheoThanhPho(cityId);
    } catch (e) {
      Get.snackbar('Lỗi', 'Xóa thất bại: $e');
    }
  }

  // ===================== UPLOAD ẢNH =====================

  // chọn ảnh từ thư viện
  Future<File?> chonAnh() async {
    final picked =
        await picker.pickImage(source: ImageSource.gallery, imageQuality: 70);
    if (picked != null) return File(picked.path);
    return null;
  }

  // upload ảnh lên supabase storage, trả về url
  Future<String?> _uploadAnh(File file, String bucket) async {
    try {
      final fileName =
          '${DateTime.now().millisecondsSinceEpoch}.jpg';
      await supabase.storage.from(bucket).upload(fileName, file);
      final url =
          supabase.storage.from(bucket).getPublicUrl(fileName);
      return url;
    } catch (e) {
      Get.snackbar('Lỗi', 'Upload ảnh thất bại');
      return null;
    }
  }
}
