import 'package:get/get.dart';
import '../main_travel.dart';
import '../model/city_model.dart';
import '../pages/login_page.dart';

class HomeController extends GetxController {
  List<CityModel> danhSachThanhPho = [];
  List<CityModel> ketQuaTimKiem = [];
  bool dangTai = false;
  String tuKhoa = '';

  @override
  void onInit() {
    super.onInit();
    layDanhSachThanhPho();
  }

  void layDanhSachThanhPho() async {
    dangTai = true;
    update(); // báo cho GetBuilder rebuild

    try {
      var data = await supabase.from('cities').select();
      danhSachThanhPho =
          (data as List).map((e) => CityModel.fromJson(e)).toList();
      ketQuaTimKiem = danhSachThanhPho;
    } catch (e) {
      Get.snackbar('Lỗi', 'Không tải được dữ liệu');
    }

    dangTai = false;
    update(); // rebuild lại sau khi có dữ liệu
  }

  void timKiem(String text) {
    tuKhoa = text;
    if (tuKhoa.isEmpty) {
      ketQuaTimKiem = danhSachThanhPho;
    } else {
      ketQuaTimKiem = danhSachThanhPho
          .where((tp) =>
              tp.name.toLowerCase().contains(tuKhoa.toLowerCase()))
          .toList();
    }
    update(); // rebuild danh sách
  }

  void dangXuat() async {
    await supabase.auth.signOut();
    Get.offAll(() => LoginPage());
  }
}
