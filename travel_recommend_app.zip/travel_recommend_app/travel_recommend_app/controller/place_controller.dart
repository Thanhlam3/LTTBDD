import 'package:get/get.dart';
import '../main_travel.dart';
import '../model/place_model.dart';

class PlaceController extends GetxController {
  List<PlaceModel> danhSachDiaDiem = [];
  List<PlaceModel> tabHienTai = []; // danh sách theo tab đang chọn
  bool dangTai = false;
  String tabDangChon = 'tham_quan'; // tab mặc định

  // lấy địa điểm theo thành phố
  void layDiaDiem(int cityId) async {
    dangTai = true;
    update();

    try {
      var data = await supabase
          .from('places')
          .select()
          .eq('city_id', cityId);

      danhSachDiaDiem =
          (data as List).map((e) => PlaceModel.fromJson(e)).toList();

      // lọc theo tab đang chọn
      locTheoLoai(tabDangChon);
    } catch (e) {
      Get.snackbar('Lỗi', 'Không tải được địa điểm');
    }

    dangTai = false;
    update();
  }

  // lọc danh sách theo loại (tab)
  void locTheoLoai(String loai) {
    tabDangChon = loai;
    tabHienTai =
        danhSachDiaDiem.where((p) => p.loai == loai).toList();
    update();
  }
}
