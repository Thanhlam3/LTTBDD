import 'package:get/get.dart';
import '../main_travel.dart';

class AuthController extends GetxController {
  String role = 'user'; // mặc định là user
  bool dangTaiRole = false;

  // kiểm tra có phải admin không
  bool get laAdmin => role == 'admin';

  // email người dùng hiện tại (null nếu chưa đăng nhập)
  String? get email => supabase.auth.currentUser?.email;

  // tên hiển thị: lấy phần trước @ của email
  String get tenHienThi {
    final e = email;
    if (e == null) return 'Khách';
    return e.split('@').first;
  }

  @override
  void onInit() {
    super.onInit();
    // nếu đã đăng nhập thì lấy role luôn
    if (supabase.auth.currentUser != null) {
      layRole();
    }

    // lắng nghe thay đổi trạng thái đăng nhập
    supabase.auth.onAuthStateChange.listen((data) {
      if (data.session != null) {
        layRole(); // đăng nhập → lấy role
      } else {
        role = 'user'; // đăng xuất → reset về user
        update();
      }
    });
  }

  // lấy role của user hiện tại từ bảng profiles
  void layRole() async {
    dangTaiRole = true;
    update();

    try {
      var userId = supabase.auth.currentUser?.id;
      if (userId == null) return;

      var data = await supabase
          .from('profiles')
          .select('role')
          .eq('id', userId)
          .single();

      role = data['role'] ?? 'user';
    } catch (e) {
      role = 'user'; // lỗi thì coi như user thường
    }

    dangTaiRole = false;
    update();
  }
}
