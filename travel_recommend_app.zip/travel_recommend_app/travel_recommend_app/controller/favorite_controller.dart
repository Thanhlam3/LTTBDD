import 'package:get/get.dart';
import '../main_travel.dart';
import '../model/place_model.dart';

class FavoriteController extends GetxController {
  List<PlaceModel> danhSachYeuThich = [];
  List<int> idYeuThich = []; // lưu id để check nhanh
  bool dangTai = false;

  @override
  void onInit() {
    super.onInit();
    layDanhSachYeuThich();
  }

  void layDanhSachYeuThich() async {
    var userId = supabase.auth.currentUser?.id;
    if (userId == null) return;

    dangTai = true;
    update();

    try {
      // join bảng favorites với places
      var data = await supabase
          .from('favorites')
          .select('place_id, places(*)')
          .eq('user_id', userId);

      danhSachYeuThich = (data as List)
          .map((e) => PlaceModel.fromJson(e['places']))
          .toList();

      idYeuThich = danhSachYeuThich.map((p) => p.id).toList();
    } catch (e) {
      Get.snackbar('Lỗi', 'Không tải được yêu thích');
    }

    dangTai = false;
    update();
  }

  // kiểm tra địa điểm có trong yêu thích không
  bool daYeuThich(int placeId) {
    return idYeuThich.contains(placeId);
  }

  // thêm hoặc xóa yêu thích
  void toggleYeuThich(PlaceModel place) async {
    var userId = supabase.auth.currentUser?.id;
    if (userId == null) {
      Get.snackbar('Thông báo', 'Đăng nhập để lưu yêu thích');
      return;
    }

    if (daYeuThich(place.id)) {
      // xóa khỏi yêu thích
      await supabase
          .from('favorites')
          .delete()
          .eq('user_id', userId)
          .eq('place_id', place.id);

      danhSachYeuThich.removeWhere((p) => p.id == place.id);
      idYeuThich.remove(place.id);
    } else {
      // thêm vào yêu thích
      await supabase.from('favorites').insert({
        'user_id': userId,
        'place_id': place.id,
      });

      danhSachYeuThich.add(place);
      idYeuThich.add(place.id);
    }

    update(); // rebuild
  }

  // xóa khỏi yêu thích (dùng ở trang favorite với slidable)
  void xoaYeuThich(int placeId) async {
    var userId = supabase.auth.currentUser?.id;
    if (userId == null) return;

    await supabase
        .from('favorites')
        .delete()
        .eq('user_id', userId)
        .eq('place_id', placeId);

    danhSachYeuThich.removeWhere((p) => p.id == placeId);
    idYeuThich.remove(placeId);
    update();
  }
}
