import 'package:flutter/material.dart';

class MyProfile extends StatefulWidget {
  const MyProfile({super.key});

  @override
  State<MyProfile> createState() => _MyProfileState();
}

class _MyProfileState extends State<MyProfile> {

  DateTime ngaySinh = DateTime(2005);
  String? gioiTinh = "Nữ";
  List<String> nnlts = ["C++", "C#", "JAVA", "Python"];
  String? nnlt = "JAVA";
  int currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("My Profile"),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
      ),
      drawer: Drawer(
         child: ListView( // nên dùng list view hơn column
           children: [
             UserAccountsDrawerHeader(
                 accountName: Text("Phạm Thanh Lâm"),
                 accountEmail: Text("thanhlam@gmail.com"),
                // tùy chỉnh kích thước avt currentAccountPictureSize: ,
                 currentAccountPicture: CircleAvatar( // tạo avtart user
                   backgroundImage: AssetImage("asset/images/2521.jpg"),
                 ),
             ),
             ListTile(
               title: Text("Inbox"),
               trailing: Text("10"),
               leading: Icon(Icons.mail),
             ),
             ListTile(
               onTap: () {
                 setState(() {
                   currentIndex = 1;
                 });
                 Navigator.of(context).pop();
               },
               title: Text("SMS"),
               trailing: Text("90"),
               leading: Icon(Icons.sms, color: Colors.orange,),
             ),
             ListTile(
               onTap: () {
                 setState(() {
                   currentIndex = 2;
                 });
                 Navigator.of(context).pop();
               },
               title: Text("Settings"),
               leading: Icon(Icons.settings),
             ),
             Divider(thickness: 1.5,)
           ],
         ),
      ),
      body: _buildbody(currentIndex),
      bottomNavigationBar: BottomNavigationBar( // thanh điều hướng ở dưới để chuyển đổi trang
        currentIndex: currentIndex,
          unselectedItemColor: Colors.grey,
          selectedItemColor: Colors.blue[800],
          onTap: (value) { // sự kiện để chuyển đổi giữa các trang dựa vào hàm buildbody trong switch case
            setState(() {
              currentIndex = value;
            });
          },
          items: [
            // các thành phần của botomNavigationBar, sẽ hoạt động từ 2 item trở lên
            BottomNavigationBarItem(
              label: "Home",
              icon: Icon(Icons.home, color: Colors.blue,),
            ),
            BottomNavigationBarItem(
              label: "SMS",
              icon: Icon(Icons.sms, color: Colors.orange,),
            ),
            BottomNavigationBarItem(
              label: "Settings",
              icon: Icon(Icons.settings, color: Colors.black,),
            ),
          ]
      ),
    );
  }
  // các hàm widget để chuyển đổi giữa các trang
  Widget _buildSMS(){
    return Center(
      child: Text("SMS", style: TextStyle(fontSize: 20),),
    );
  }
  Widget _buildSetiings(){
    return Center(
      child: Text("settings", style: TextStyle(fontSize: 20),),
    );
  }
  Widget _buildHome(){
    return
      Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
    Center(
    child: Container(
    height: 300,
    width: 350,
    child: Image.asset("asset/images/namri.jpg"),
    ),
    ),
    // SizedBox(height: 15,),
    Text("Họ Tên:"),
    Text("Phạm Thanh Lâm",
    style: TextStyle(color: Colors.blue, fontWeight: FontWeight.bold, fontSize: 18),
    ),
    SizedBox(height: 15,),
    Text("Ngày sinh:"),
    Row(
    children: [
    Expanded(child: Text("${ngaySinh.day}/${ngaySinh.month}/${ngaySinh.year}")),
    IconButton(
    onPressed: () async{
    var selectedDate = await showDatePicker(
    context: context,
    firstDate: DateTime(1980),
    lastDate: DateTime(2040),
    currentDate: ngaySinh
    );
    if(selectedDate!=null){
    setState(() {
    ngaySinh = selectedDate;
    });
    }
    },
    icon: Icon(Icons.calendar_month)
    ),
    SizedBox(width: 25,),
    ],
    ),
    SizedBox(height: 15,),
    Text("Giới Tính:"),
    RadioGroup(
    groupValue: gioiTinh,
    onChanged: (value) {
    setState(() {
    gioiTinh = value; // cần gán biến cho string? đển có thể nhận giá trị null
    });
    },
    child: Row(
    children: [
    Expanded( // cần cho radiolis ttitle được bọc bởi expanded, vì radiolisttitle ko thể đo giá trị cho biến value gây nên lỗi hasSize
    child: RadioListTile(
    value: "Nam",
    title: Text("Nam"),
    ),
    ),
    Expanded(
    child: RadioListTile(
    value: "Nữ",
    title: Text("Nữ"),
    ),
    ),
    ],
    ),
    ),
    SizedBox(height: 15,),
    Text("Sở Thích:"),
    Text("Xem Phim, Nghe Nhạc, everything",
    style: TextStyle(fontStyle: FontStyle.italic),
    ),
    SizedBox(height: 15,),
    Text("Ngôn ngữ lập trình giỏi nhất của bạn"),
    DropdownButton<String>(
    isExpanded: true,
    value: nnlt,
    items: nnlts.map( // phương thức map chuyển đổi danh sách nnlt thành danh sách các dropdown menu item
    (e) {
    return DropdownMenuItem<String>(
    child: Text(e),
    value: e,
    );
    },
    ).toList(),
    onChanged: (value) {
    setState(() {
    nnlt = value;
    });
    },
    ),
    ],
    );// chỗ này là body copy xuống
  }
  Widget _buildbody(int index){
    switch(index){
      case 0: return _buildHome();
      case 1: return _buildSMS();
      case 2: return _buildSetiings();
    }
    return _buildHome();
  }
}
