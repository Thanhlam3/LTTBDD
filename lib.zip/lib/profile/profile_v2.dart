import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_instance/src/extension_instance.dart';
import 'package:lamthanh/profile/controllerProfile.dart';
import 'package:lamthanh/profile/model_profile.dart';

class MyProfileV2 extends StatelessWidget {
   MyProfileV2({super.key});
   final Controllerprofile controller = Get.put(Controllerprofile());
   TextEditingController txtName = TextEditingController();
   final TextEditingController txtSoThich = TextEditingController();
  @override
  Widget build(BuildContext context) {
    txtName.text = controller.profile.ten;
    txtSoThich.text = controller.profile.soThich;
    return Scaffold(
      appBar: AppBar(
        title: Text("Thanh Lam profile"),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Center(
              child: Container(
                width: 300,
                height: 200,
                child: Image.asset("asset/images/2521.jpg"),
              ),
            ),
            GetBuilder<Controllerprofile>(
              init: controller,
              id: 'profile',
              builder: (controller){
                Profile p = controller.profile;
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("Họ Tên:"),
                    TextField(
                      controller: txtName,
                      readOnly: !controller.editTable,
                      onChanged: (value) => controller.profile.ten = value,
                    ),
                    Text("Giới Tính"),
                    RadioGroup(
                        groupValue: p.gioiTinh,
                        onChanged: (value) {
                          if(controller.editTable){
                            controller.profile.gioiTinh = value!;
                            controller.refresh();
                          }
                        },
                      child: Row(
                        children: [
                          Expanded(
                            child: RadioListTile(
                              value: "Nam",
                              title: Text("Nam"),
                            ),
                          ),
                          Expanded(
                            child: RadioListTile(
                              value: "Nu",
                              title: Text("Nu"),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Text("Sở thích:"),
                    TextField(
                      controller: txtSoThich,
                      readOnly: !controller.editTable,
                      onChanged: (value) => controller.profile.soThich = value,
                    ),
                    Text("Ngôn ngữ lập trình:"),
                    DropdownButton<String>(
                      isExpanded: true,
                      value: controller.nnlts.contains(p.nnlt) ? p.nnlt : null,
                      hint: Text("Ngôn ngữ lập trình yêu thích"),
                      items: controller.nnlts.map((String lang) {
                        return DropdownMenuItem<String>(
                          value: lang,
                          child: Text(lang),
                        );
                      }).toList(),
                      onChanged: controller.editTable ? (String? newValue) {
                        if (newValue != null) {
                          controller.profile.nnlt = newValue;
                          controller.refresh();
                        }
                      } : null,
                    ),

                  ],
                );
              },
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                ElevatedButton(
                    onPressed: () {
                      controller.allowEdit();
                    },
                    child: Text("edit")
                ),
                SizedBox(width: 10,),
                ElevatedButton(
                    onPressed: () async{
                      await controller.saveProfile();
                      ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text("da luu thong tin profile"))
                      );
                    },
                    child: Text("save")
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
