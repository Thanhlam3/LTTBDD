import 'package:get/get.dart';
import 'package:lamthanh/profile/model_profile.dart';

class Controllerprofile extends GetxController{
  late Profile profile;
  bool editTable = false;
  List<String> nnlts = ["C++", "C#", "JAVA", "Python"];

  @override
  void onReady() {
    // TODO: implement onReady
    super.onReady();
    ProfileSnapshot.loadProfile().then(
          (value) {
        profile = value;
        update(['profile']);
      },
    );
  }
    Future<void> saveProfile() async{
      await ProfileSnapshot.saveProfile(profile);
      editTable = false;
      update(['profile']);
    }
    void allowEdit(){
      editTable = true;
      update(['profile']);
    }
    void refresh(){
      update(['profile']);
    }
  }
