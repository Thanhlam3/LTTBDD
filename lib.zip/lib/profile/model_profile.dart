import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

class Profile{
  String ten, soThich, nnlt;
  int? ngaySinh;
  String gioiTinh;

  Profile({
    required this.ten,
    required this.soThich,
    required this.nnlt,
    required this.ngaySinh,
    required this.gioiTinh,
  });

  Map<String, dynamic> toMap() {
    return {
      'ten': this.ten,
      'soThich': this.soThich,
      'nnlt': this.nnlt,
      'ngaySinh': this.ngaySinh,
      'gioiTinh': this.gioiTinh,
    };
  }

  @override
  String toString() {
    return jsonEncode(toMap());
  }

  factory Profile.fromMap(Map<String, dynamic> map) {
    return Profile(
      ten: map['ten'] as String,
      soThich: map['soThich'] as String,
      nnlt: map['nnlt'] as String,
      ngaySinh: map['ngaySinh'] as int,
      gioiTinh: map['gioiTinh'] as String,
    );
  }

}

class ProfileSnapshot{
  static Future<Profile> loadProfile() async{
    SharedPreferences preferences = await
     SharedPreferences.getInstance();
    String? s = preferences.getString("profile");
    if(s!=null){
      return Profile.fromMap(jsonDecode(s));
    }
    else{
      return Profile(
          ten: "Phạm Thanh Lâm",
          soThich: "nghe nhạc, xem phim,...",
          nnlt: "java",
          ngaySinh: DateTime(2005,8,9).microsecond,
          gioiTinh: "Nam"
      );
    }
  }

  static Future<void> saveProfile(Profile p) async{
    SharedPreferences preferences = await
     SharedPreferences.getInstance();
    preferences.setString("profile", p.toString());
  }
}