
import 'package:get/get.dart';

class ControllerCounter extends GetxController{
  final counter = 0.obs;
  void increment(){
    counter.value++;
  }
}

class ControlleSimple extends GetxController{
  int counter = 0;
  static ControlleSimple get({String? tag}) => Get.find(tag: tag);

  void increment(){
    counter++;
    update(["01", "02"], counter <= 30);

  }
}
