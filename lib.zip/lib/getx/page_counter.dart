import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lamthanh/getx/controller_counter.dart';

class PageCounter extends StatelessWidget {
  PageCounter({super.key});
  final ControllerCounter c = Get.put(ControllerCounter());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("GETX controller"),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text("counter"),
            Obx(() => Text("${c.counter.value}"),),
            GetX<ControllerCounter>(
              init: Get.put(ControllerCounter(), tag: "my_controller"),
              tag: "my_controller",
              builder: (controller) => Text("${controller.counter.value}"),
            ),

            GetBuilder<ControlleSimple>(
                init: Get.put(ControlleSimple()),
                id: "01",
                builder: (controller) => Text("${controller.counter}"),
            ),

            GetBuilder<ControlleSimple>(
              init: Get.put(ControlleSimple()),
              id: "02",
              builder: (controller) => Text("${controller.counter}"),
            ),

            ElevatedButton(
                onPressed: (){
                  c.increment();
                  ControllerCounter c1 = Get.find(tag: "my_controller");
                  c1.increment();
                  ControlleSimple.get().increment();
                },

                child: Text("tăng")
            )
          ],
        ),
      ),
    );
  }
}
