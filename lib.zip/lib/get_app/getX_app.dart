import 'package:flutter/material.dart';
import 'package:get/get.dart';

class GetxApp extends StatelessWidget {
  const GetxApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      theme: ThemeData(
        colorScheme: .fromSeed(seedColor: Colors.pinkAccent),
      ),
      home: PageGetxHome(),
    );
  }
}
class PageGetxHome extends StatelessWidget {
  const PageGetxHome({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("getx app"),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
                onPressed: () async {
                 var data = await Get.to(PageSecond());
                 print(data);
                },
                child: Text("second page")
            ),
            ElevatedButton(
                onPressed: () {
                  Get.off(PageThird());
                },
                child: Text("third page")
            ),
          ],
        ),
      ),
    );
  }
}

class PageSecond extends StatelessWidget {
  const PageSecond({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("second"),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
      ),
      body: Center(
        child: ElevatedButton(
            onPressed: () {
              Get.back(result: "Goodbye");
            },
            child: Text("go home")
        ),
      ),
    );
  }
}

class PageThird extends StatelessWidget {
  const PageThird({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("third"),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
      ),
      body: Center(
        child: ElevatedButton(
            onPressed: () {
              Get.back();
            },
            child: Text("back")
        ),
      ),
    );
  }
}

