import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lamthanh/page_home.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'profile/profile.dart';

void main() async {
  runApp(const MyApp());

  await Supabase.initialize(
    url: 'https://ywhobohkrrwtxoptrkgn.supabase.co',
    anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOi'
        'JzdXBhYmFzZSIsInJlZiI6Inl3aG9ib2hrcnJ3dHhvcHRya2duIiwicm9s'
        'ZSI6ImFub24iLCJpYXQiOjE3NzQzMzY2NTksImV4cCI6MjA4OTkxMjY1OX0.af3'
        'A5WZ5MFRbqmwQ6Jf2q5HO9i8A0ZduGEjpOZfO0Qg',
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(

        colorScheme: .fromSeed(seedColor: Colors.pinkAccent),
      ),
       // home: const MyHomePage(title: 'Flutter Demo Home Page'),
      // home: MyProfile(),  // chỗ thay homepage, thay tên class
      home: PageHome651(),

    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});



  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _counter = 0;

  void _incrementCounter() {
    setState(() {

      _counter++;
    });
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(

        backgroundColor: Theme.of(context).colorScheme.inversePrimary,

        title: Text("Phạm Thanh Lâm App"),
      ),
      drawer: Drawer(),

      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            Container(
              height: 400,
              child: Image.network("https://cdn.tienphong.vn/images/a6bf4f60924201126af6849ca45a3980e76ea1ce783b7b7bfe465da8d1f4abc5a42edee1c2d8329e07f7c3a74caa458ff89e5929e49ffa7ee6a5ab699dbdd831/2521-110-9341.jpg"),
            ),
            Container(
              child: Text("Twenty Five Twenty One",
              style: TextStyle(fontSize: 20, color: Colors.pink)),
            ),
          Row(
            children: [
              Icon(Icons.star, color: Colors.orangeAccent,),
              Icon(Icons.star, color: Colors.orangeAccent,),
              Icon(Icons.star, color: Colors.orangeAccent,),
              Icon(Icons.star, color: Colors.orangeAccent,),
              Icon(Icons.star_half, color: Colors.orangeAccent,),
              SizedBox(width: 20,),
              Text("4.5"),
            ],
          ),

          // mainAxisAlignment: .center,

            Text("Đây là bài tập đầu tiên của em, thầy cho em 10 điểm nhé"),
            const Text('Click nhiều lần để tăng or giảm:',
              style: TextStyle(fontSize: 20, color: Colors.red),
            ),
            Text(
              '$_counter',
              style: Theme.of(context).textTheme.headlineMedium,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                    onPressed: () =>
                      _incrementCounter(),
                    child: Text("Tăng")
                ),
                SizedBox(width: 30,),
                ElevatedButton(
                    onPressed: () {
                      setState(() {
                        _counter--;
                  });
                },
                    child: Text("Giảm")
                )
              ],
            )
          ],
        ),
      ),
      // floatingActionButton: FloatingActionButton(
      //   onPressed: _incrementCounter,
      //   tooltip: 'Increment',
      //   child: const Icon(Icons.add),
      // ),
    );
  }
}
