
import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:lamthanh/rss/model/rss_item.dart';
import 'package:lamthanh/rss/model/rss_resouce.dart';
import 'package:xml2json/xml2json.dart';

String _rssURLVNexpress = "https://vnexpress.net/rss/tin-moi-nhat.rss";

void main() async{
  final response = await http.get(Uri.parse(_rssURLVNexpress));
  if(response.statusCode == 200){
    //print(response.body);
    final xml2jon = Xml2Json();
    xml2jon.parse(utf8.decode(response.bodyBytes));
    String rssJson = xml2jon.toParker();
    //print(rssJson);
    Map<String, dynamic> jsonData = jsonDecode(rssJson);
    var testData = jsonData["rss"]["channel"]["item"][0];
    // print(testData);
    // print(testData['title']); print("\n");
    // print(testData['link']); print("\n");
    // print(testData['description']); print("\n");
    // print(testData['pubDate']); print("\n");

    RSSItem rssItem = RSSItem.empty().fromJson(testData, r: rssResource[0]);
    print(rssItem.imageUrl); print("\n");
    print(rssItem.description); print("\n");
  }
}