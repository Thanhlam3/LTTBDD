import 'dart:convert';

import 'package:get/get.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';
import 'package:http/http.dart' as http;
import 'package:lamthanh/rss/model/rss_item.dart';
import 'package:lamthanh/rss/model/rss_resouce.dart';
import 'package:xml2json/xml2json.dart';

class SimpleControllerRss extends GetxController {
  List<RssResource> resources = rssResource; // ds nguon bao
  RssResource currentResource = rssResource[0]; // nguon bao dang su dung
  String? _rssUrl; // lk rss url dang hien thi
  String? _resourceHeader; // ten dau muc cua muc bao trog nguon bao dang sd
  var _rssList = <RSSItem>[]; // ds cac rss item dang hien thi
  var favoriteNews = <RSSItem>[];
  List<RSSItem> get rssList => _rssList;

  String get currentResourceName => currentResource.name;

  String? get resourceHeader => _resourceHeader;

  List<String> get headerResources =>
      currentResource.resourceHeader.keys.toList(); // ds cac dau muc cua nguon bao dang sd

  // viet thuoc tinh truy cap controller
  static SimpleControllerRss get instance =>
      Get.find<SimpleControllerRss>();

  @override
  void onInit() {
    super.onInit();
    if (_rssUrl == null) {
      _rssUrl = currentResource.resourceHeader.values.toList()[0];
    }
    if (_resourceHeader == null) {
      _resourceHeader = currentResource.resourceHeader.keys.toList()[0];
    }
  }

  @override
  void onReady() {
    super.onReady();
    readRss();

    RssItemSnapshot.loadFavouriteRss().then((loadedFavorites) {
      favoriteNews = loadedFavorites;
      update(["favorites"]); // Cập nhật lại giao diện trang Favorite
    });
  }

  Future<void> readRss() async {
    _fetchRSS(_rssUrl!)
        .then((value) {
      _rssList = value
          ?.map((e) =>
          RSSItem.empty()
              .fromJson(e, r: currentResource))
          .toList() ??
          [];

      update(["listRss"]);
    }).onError((error, stackTrace) {
      print("Lỗi đọc rss: $error");
    });
  }


  Future<List<dynamic>?> _fetchRSS(String rssURL) async {
    final response = await http.get(Uri.parse(rssURL));
    if (response.statusCode == 200) {
      //print(response.body);
      final xml2jon = Xml2Json();
      xml2jon.parse(utf8.decode(response.bodyBytes));
      String rssJson = xml2jon.toParker();
      //print(rssJson);
      Map<String, dynamic> jsonData = jsonDecode(rssJson);
      return jsonData ["rss"]["channel"]["item"];
    }
    print("Lỗi đọc rss");
    return Future.error("loi doc rss");
  }


  void changeHeader(String newHeader){
    _resourceHeader = newHeader; // cập nhật lại tên key mới
    update(["headers"]); // refresh biến header trog getbuilder bên page
    _rssUrl = currentResource.resourceHeader[newHeader]; // cập nhật lại nguồn báo currentResource tương ứng với resourceHeader vào biến mới header
    readRss(); //gọi hàm read
  }

  void changeResource(String resourceName){
    for(var re in resources){
      if(re.name == resourceName){
        currentResource = re;
      }
    }
    _resourceHeader = currentResource.resourceHeader.keys.toList()[0];
    _rssUrl = currentResource.resourceHeader.values.toList()[0];
    readRss();
    update(["name", "headers", "drawer"]);

  }

  void addFavorite(RSSItem item) {
    // Kiểm tra xem bài báo đã có trong danh sách chưa (dựa vào link) để tránh trùng lặp
    bool tontai = favoriteNews.any((favItem) => favItem.link == item.link);

    if (!tontai) {
      favoriteNews.add(item); // Thêm vào danh sách
      RssItemSnapshot.saveRssItems(favoriteNews); // Lưu xuống SharedPreferences
      update(["favorites"]); // Báo cho GetBuilder id "favorites" làm mới dữ liệu

      // Hiển thị thông báo nhỏ (SnackBar) cho người dùng
      Get.snackbar("Thành công", "Đã thêm vào danh sách yêu thích", snackPosition: SnackPosition.BOTTOM, duration: Duration(seconds: 2));
    } else {
      Get.snackbar("Thông báo", "Bài viết này đã có trong danh sách", snackPosition: SnackPosition.BOTTOM, duration: Duration(seconds: 2));
    }
  }
}

// viết lớp bindings
class RssBindings extends Bindings{
  @override
  void dependencies() {
    Get.put(SimpleControllerRss());
  }
}

