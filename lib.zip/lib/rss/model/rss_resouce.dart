
class RssResource {
  String id, name;
  String startDescriptionRegex, endDescriptionRegex;
  String startImageRegex, endImageRegex;
  Map<String, String> resourceHeader;

  // alt + insert --> named argument contructor
  RssResource({
    required this.id,
    required this.name,
    required this.startDescriptionRegex,
    required this.endDescriptionRegex,
    required this.startImageRegex,
    required this.endImageRegex,
    required this.resourceHeader,
  });
}
List<RssResource> rssResource = [
  RssResource(
      id: "vnexpress",
      name: "VN Express",
      startDescriptionRegex: "</a></br>",
        endDescriptionRegex: "",
      startImageRegex: '<img src="',
        endImageRegex: '"',
      resourceHeader: {
        "Trang chủ":"https://vnexpress.net/rss/tin-moi-nhat.rss",
        "Thế Giới":"https://vnexpress.net/rss/the-gioi.rss",
        "Thể thao":"https://vnexpress.net/rss/the-thao.rss",
        "Giải trí":"https://vnexpress.net/rss/giai-tri.rss",
        "Pháp luật":"https://vnexpress.net/rss/phap-luat.rss",
        "Cười":"https://vnexpress.net/rss/cuoi.rss",
        "Đời sống":"https://vnexpress.net/rss/gia-dinh.rss",
        "Tâm sự":"https://vnexpress.net/rss/tam-su.rss",
        "Xe":"https://vnexpress.net/rss/oto-xe-may.rss",

      }),
  RssResource(
      id: "vnexpress",
      name: "xe",
      startDescriptionRegex: "</a></br>",
      endDescriptionRegex: "",
      startImageRegex: '<img src="',
      endImageRegex: '"',
      resourceHeader: {
        "Xe":"https://vnexpress.net/rss/oto-xe-may.rss",

      }),
  RssResource(
      id: "vnexpress",
      name: "Phát Luật",
      startDescriptionRegex: "</a></br>",
      endDescriptionRegex: "",
      startImageRegex: '<img src="',
      endImageRegex: '"',
      resourceHeader: {
        "Pháp luật":"https://vnexpress.net/rss/phap-luat.rss",

      })

];


