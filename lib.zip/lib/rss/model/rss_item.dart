

import 'dart:convert';

import 'package:lamthanh/rss/model/rss_resouce.dart';
import 'package:shared_preferences/shared_preferences.dart';

class RSSItem {
  String? title;
  String? pubDate;
  String? description;
  String? link;
  String? imageUrl;


  RSSItem({
    this.title,
    this.pubDate,
    this.description,
    this.link,
    this.imageUrl,
  });

  RSSItem.empty();

  RSSItem fromJson(Map<String, dynamic> json, {required RssResource r}) {
    title = json['title'];
    pubDate = json['pubDate'];
    description = _getDescriptionUrl(json['description'], r: r);
    link = json['link'];
    imageUrl = _getImageUrl(json['description'], r: r);
    return this;
  }



  String _getDescriptionUrl(String rawDescription, {required RssResource r}) {
    String startRegrex = r.startDescriptionRegex;
    String endRegrex = r.endDescriptionRegex;
    int start = rawDescription.indexOf(startRegrex) + startRegrex.length;
    if (start >= startRegrex.length){
      if(endRegrex.length>0){
        int end = rawDescription.indexOf(endRegrex, start);
        return rawDescription.substring(start, end);
      }
      return rawDescription.substring(start);
    }
    return "";
  }

  String? _getImageUrl(String rawDescription, {required RssResource r}) {
    String startRegrex = r.startImageRegex;
    String endRegrex = r.endImageRegex;
    int start = rawDescription.indexOf(startRegrex) + startRegrex.length;
    if (start >= startRegrex.length){
      if(endRegrex.length>0){
        int end = rawDescription.indexOf(endRegrex, start);
        return rawDescription.substring(start, end);
      }
        return rawDescription.substring(start);
    }
    return null;
  }

  Map<String, dynamic> toMap() {
    return {
      'title': this.title,
      'pubDate': this.pubDate,
      'description': this.description,
      'link': this.link,
      'imageUrl': this.imageUrl,
    };
  }

  factory RSSItem.fromMap(Map<String, dynamic> map) {
    return RSSItem(
      title: map['title'] as String,
      pubDate: map['pubDate'] as String,
      description: map['description'] as String,
      link: map['link'] as String,
      imageUrl: map['imageUrl'] as String,
    );
  }
}

class RssItemSnapshot{
  static Future<void> saveRssItems(List<RSSItem> items) async{
    SharedPreferences preferences = await SharedPreferences.getInstance();
    preferences.setString("favourite", _toStringJson(items));

  }
  static Future<List<RSSItem>> loadFavouriteRss() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    String? s = preferences.getString("favourite");
    if (s == null)
      return [];
    var list = jsonDecode(s) as List;
    List<RSSItem> rssItem = [];
    for (var item in list) {
      rssItem.add(RSSItem.fromMap(item));
    }
    return rssItem;
  }
  static String _toStringJson(List<RSSItem> items){
    List<Map<String, dynamic>> list = [];
    for(var item in items){
      list.add(item.toMap());
    }
    return jsonEncode(list);
  }

}