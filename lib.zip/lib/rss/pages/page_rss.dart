import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:get/get.dart';
import 'package:lamthanh/rss/controller/rss_controller_simple.dart';
import 'package:lamthanh/rss/model/rss_item.dart';

import 'page_view_rss.dart';
import 'page_favorite_rss.dart';


class RssApp extends StatelessWidget {
  const RssApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp( // tra ve la 1 app ko phai man hinh scafford
      theme: ThemeData(
        colorScheme: .fromSeed(seedColor: Colors.blueAccent),
        //useMaterial3: true,  dung mau mac dinh, la mau xam
      ),
      initialBinding: RssBindings(),
      smartManagement: SmartManagement.full,
      home: PageRss(),

    );
  }
}


class PageRss extends StatelessWidget {
  PageRss({super.key});
  //final SimpleControllerRss controllerRss = Get.put(SimpleControllerRss());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: GetBuilder(
            id: "name",
            init: SimpleControllerRss.instance,
            builder:  (controller) => Text(SimpleControllerRss.instance.currentResourceName)
        ),
        actions: [
          GetBuilder(
            init: SimpleControllerRss.instance,
            id: "headers",
            builder: (controller) {
              List<String> headers = SimpleControllerRss.instance.headerResources;
              return DropdownButton(
                  value: controller.resourceHeader,
                  items: headers.map(
                    (e) {
                      return DropdownMenuItem(
                        child: Text(e),
                        value: e,
                      );
                    },
                  ).toList(),
                  onChanged: (value) {
                    controller.changeHeader(value!); // cần as String or !
                  },
              );
            },
          )
        ],
      ),
      drawer: Drawer(
        child: ListView(
          children: [
            UserAccountsDrawerHeader(
              accountName: Text("Phạm Thanh Lâm"),
              accountEmail: Text("thanhlam@gmail.com"),
              currentAccountPicture: CircleAvatar(
                backgroundImage: AssetImage("asset/images/2521.jpg"),
              ),
            ),
            ListTile(
              leading: Icon(Icons.favorite, color: Colors.red),
              title: Text("Tin tức yêu thích"),
              onTap: () {
                Get.back();
                Get.to(() => PageFavoriteRss()); // Chuyển hướng sang trang Favorite
              },
            ),
            Divider(),

            Padding(
              padding: const EdgeInsets.only(left: 16.0, top: 8.0, bottom: 8.0),
              child: Text("Chọn nguồn báo", style: TextStyle(fontWeight: FontWeight.bold)),
            ),

            GetBuilder<SimpleControllerRss>(
                init: SimpleControllerRss.instance,
                id: "drawer",
              builder: (controller) {

                return Column(
                  children: controller.resources.map(
                        (e) => RadioListTile<String>(
                      title: Text(e.name),
                      value: e.name,
                      groupValue: controller.currentResourceName,
                      onChanged: (value) {
                        controller.changeResource(value!);
                        Get.back();
                      },
                    ),
                  ).toList(),
                );
              },

            )
          ],

        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: RefreshIndicator(
          onRefresh: () => SimpleControllerRss.instance.readRss(),
          child: GetBuilder<SimpleControllerRss>(
            id: "listRss",
            init: SimpleControllerRss.instance,
            builder: (controller){
              List<RSSItem> listRss = controller.rssList;
              return ListView.separated(
                  itemBuilder: (context, index) {
                    RSSItem item = listRss[index];
                    return Slidable(
                      endActionPane: ActionPane(
                        extentRatio: 0.5,
                        motion:  ScrollMotion(),
                        children: [

                          SlidableAction(
                            onPressed: (context) {
                              controller.addFavorite(item);
                            },
                            backgroundColor:  Colors.lightBlueAccent,
                            foregroundColor: Colors.white,
                            icon: Icons.favorite,
                            label: 'Like',
                          ),
                        ],
                      ),
                      child: Column(
                        children: [
                          Row(
                            children: [
                              Expanded(
                                flex: 1,
                                  child: Image.network(item.imageUrl?? "no url")
                              ),
                              Expanded(
                                flex: 2,
                                  child: GestureDetector(
                                    onTap: () {
                                      Navigator.of(context).push(
                                          MaterialPageRoute(
                                              builder: (context) => PageViewRss(nameResource: controller.currentResourceName, url: item.link?? "no link",),
                                          )
                                      );
                                    },
                                    child: Text(item.title?? "no title",
                                      style: TextStyle(
                                        color: Colors.blue,
                                      ),
                                    ),
                                  ),
                      
                              )
                            ],
                          ),
                          SizedBox(height: 10,),
                          Text(item.description?? ""),
                        ],
                      ),
                    );
                  },
                  separatorBuilder: (context, index) => Divider(),
                  itemCount: listRss.length
              );
            },
          ),
        ),

      ),
    );
  }
}

