import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lamthanh/rss/controller/rss_controller_simple.dart';
import 'package:lamthanh/rss/model/rss_item.dart';
import 'page_view_rss.dart';

class PageFavoriteRss extends StatelessWidget {
  const PageFavoriteRss({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Tin Tức Yêu Thích"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: GetBuilder<SimpleControllerRss>(
          id: "favorites", // ID này khớp với update(["favorites"]) trong controller
          init: SimpleControllerRss.instance,
          builder: (controller) {
            List<RSSItem> listFavorite = controller.favoriteNews;

            if (listFavorite.isEmpty) {
              return const Center(child: Text("Bạn chưa có bài viết yêu thích nào."));
            }

            return ListView.separated(
              itemCount: listFavorite.length,
              separatorBuilder: (context, index) => const Divider(),
              itemBuilder: (context, index) {
                RSSItem item = listFavorite[index];
                return Column(
                  children: [
                    Row(
                      children: [
                        Expanded(
                          flex: 1,
                          // Kiểm tra null cho imageUrl
                          child: item.imageUrl != null && item.imageUrl!.isNotEmpty
                              ? Image.network(item.imageUrl!)
                              : const Icon(Icons.image_not_supported),
                        ),
                        Expanded(
                          flex: 2,
                          child: GestureDetector(
                            onTap: () {
                              // Chuyển sang màn hình đọc chi tiết
                              Get.to(() => PageViewRss(
                                nameResource: "Tin Yêu Thích",
                                url: item.link ?? "",
                              ));
                            },
                            child: Padding(
                              padding: const EdgeInsets.only(left: 8.0),
                              child: Text(
                                item.title ?? "no title",
                                style: const TextStyle(
                                  color: Colors.blue,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                        )
                      ],
                    ),
                    const SizedBox(height: 10),
                    Text(item.description ?? "", maxLines: 3, overflow: TextOverflow.ellipsis),
                  ],
                );
              },
            );
          },
        ),
      ),
    );
  }
}