import 'package:flutter/material.dart';
import 'package:lamthanh/basic_widget.dart';
import 'package:lamthanh/commercial_app/page_fruit.dart';
import 'package:lamthanh/commercial_app/page_fruit_admin.dart';
import 'package:lamthanh/mt_chuyendoi/page_calculation.dart';
import 'package:lamthanh/permission/page_permission.dart';
import 'package:lamthanh/profile/profile.dart';
import 'package:lamthanh/sqlite/page_sqlite_app.dart';
import 'package:lamthanh/vd/list_view.dart';

import 'commercial_app/page_fruit_2.dart';
import 'commercial_app/page_login.dart';
import 'form/page_form_mathang.dart';
import 'get_app/getX_app.dart';
import 'getx/page_counter.dart';
import 'profile/profile_v2.dart';
import 'rss/pages/page_rss.dart';


class PageHome651 extends StatelessWidget {
  const PageHome651({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("MY APP"),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
      ),
      body: SingleChildScrollView(
        child: Center(
          child: Column(
            children: [
              _buildButton(context, title: "my profile", destination: MyProfile()),
              _buildButton(context, title: "my profile v2", destination: MyProfileV2()),
              _buildButton(context, title: "basic widget", destination: PageBasicWiget()),
              _buildButton(context, title: "my list view", destination: PageMyListView()),
              _buildButton(context, title: "getx controller", destination: PageCounter()),
              _buildButton(context, title: "app rss", destination: RssApp()),
              _buildButton(context, title: "getx app", destination: GetxApp()),
              //_buildButton(context, title: "supabase fruit", destination: PageFruitStream()),
              _buildButton(context, title: "supabase fruit v2", destination: PageFruit2()),
              _buildButton(context, title: "page Fruit Admin", destination: PageFruitAdmin()),
              _buildButton(context, title: "supabase login fruit", destination: PageLogin()),
              _buildButton(context, title: "supabase veryfy user", destination: PageVerifyUser(email: '',)),
              _buildButton(context, title: "page calculation", destination: PageCalculation()),
              _buildButton(context, title: "page form mat hang", destination: PageFormMathang()),
              _buildButton(context, title: "page sqlite", destination: SQLiteApp()),
              _buildButton(context, title: "page camera", destination: CameraTestPage()),


            ],
          ),
        ),
      ),
    );
  }
  Widget _buildButton(
      BuildContext context,
        {
          required String? title,
          required Widget? destination
        }
      )
  {
    return
      Padding(
        padding: const EdgeInsets.only(top: 5, bottom: 5),
        child: Container(
          width: 220,
          child: ElevatedButton(
            onPressed: () {
              Navigator.of(context).push(
                  MaterialPageRoute(
                      builder: (context) => destination! , // tên file đã tạo
                  ),
              );
            },
            child: Text(title!),
            style: ButtonStyle(
              backgroundColor: WidgetStateProperty.all(Colors.purple[50]),
              elevation: WidgetStateProperty.all(2),
            ),
          ),
        ),
      );
  }
}
