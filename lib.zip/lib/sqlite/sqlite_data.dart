import 'package:sqflite/sqflite.dart';

const String tableName = "Users";
class User{
  int? id;
  String name, phone, email;

  User({
    this.id,
    required this.name,
    required this.phone,
    required this.email,
  });

  Map<String, dynamic> toJson() => {
      'id': this.id,
      'name': this.name,
      'phone': this.phone,
      'email': this.email,
  };

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      id: json['id'] as int,
      name: json['name'] as String,
      phone: json['phone'] as String,
      email: json['email'] as String,
    );
  }

}
class DatabaseHelper {
  Database? database;
  String? _path;

  Future<String?> _getDatatbasePath(String databaseName) async {
    String p = await getDatabasesPath();
    String path = "$p/$databaseName";
    this._path = path;
    return _path;
  }

//Mở một database để làm việc, nếu CSDL chưa tòn tại, phuong thức onCreate sẽ được gọi để tạo CSDL
  Future<Database?> open() async {
    String? _path = await _getDatatbasePath('demo.db');
    database = await openDatabase(
        _path!,
        version: 1,
        onCreate: (db, version) async {
          db.execute(
              'CREATE TABLE $tableName (id INTEGER PRIMARY KEY, name TEXT, phone TEXT, email TEXT)');
        }
    );
    return database;
  }

  //Chen bộ dữ Liệu vào bản Users và trả về id của bộ dữ liệu
  Future<int> insert(User user) async {
    int id = await database!.transaction(
            (Transaction txn) async {
              int id = await txn.rawInsert(
                'INSERT INTO $tableName(name, phone, email) VALUES( ?, ?, ?)',
                [user.name, user.phone, user.email],
              );
              return id;
            }
    );
    return id;
    }

  Future<int> update(User newUser, int id) async {
    int count = await database!.transaction((Transaction txn) async {
      int count = await txn.rawUpdate(
          'UPDATE $tableName SET name = ?, phone = ?, email = ? WHERE id = ?',
          [newUser.name, newUser.phone, newUser.email, id]
      );
      return count;
    }
    );
    return count;
  }

// Xoa bộ dữ Liệu có id m id và trả về số bộ dữ liệu bị xóa
  Future<int> delete(int id) async {
    int count = await database!.rawDelete(
      "DELETE FROM $tableName WHERE id = ? ",
      [id],
    );
    return count;
  }

  Future<List<User>> getUsers() async {
    List<Map> list = await database!.rawQuery("SELECT * FROM $tableName");
    return list.map((userJson) =>
        User.fromJson(userJson as Map<String, dynamic>)).toList();
  }

  void closeDatabase() async {
    await database!.close();
  }

  void deleteDB() {
    deleteDatabase(_path!);
  }

}
