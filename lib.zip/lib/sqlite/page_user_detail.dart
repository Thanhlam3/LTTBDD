import 'package:flutter/material.dart';
import '../helpers/dialogs.dart';
import 'sqlite_data.dart';
import 'package:provider/provider.dart';
import 'provider_data.dart';

class PageUserSQLiteDetail extends StatefulWidget {
  bool? xem;
  User? user;
  PageUserSQLiteDetail({Key? key, this.xem, this.user}) : super(key: key);

  @override
  _PageUserSQLiteDetailState createState() => _PageUserSQLiteDetailState();
}
class _PageUserSQLiteDetailState extends State<PageUserSQLiteDetail> {
  bool? xem;
  User? user;
  String title = "Thong tin User";
  String buttonTitle = "Đóng";
  TextEditingController txtTen = TextEditingController();
  TextEditingController txtPhone = TextEditingController();
  TextEditingController txtEmail = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(title!),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: SingleChildScrollView(
          child: Column(
            children: [
              TextField(
                controller: txtTen,
                decoration: const InputDecoration(
                  label: Text("Tên:"),
                ),
              ),
              const SizedBox(height: 10,),
              TextField(
                controller: txtPhone,
                decoration: const InputDecoration(
                  label: Text("Phone:"),
                ),
                keyboardType: TextInputType.phone,
              ),
              const SizedBox(height: 10,),
              TextField(
                controller: txtEmail,
                decoration: const InputDecoration(
                  label: Text("Email:"),
                ),
                keyboardType: TextInputType.emailAddress,
              ),
              const SizedBox(height: 10,),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  ElevatedButton(
                    onPressed: () => _capNhat(context),
                    child: Text(buttonTitle!),
                  ),
                  const SizedBox(width: 10,),
                  xem == true ? const SizedBox(width: 1,) :
                  ElevatedButton(
                    onPressed: () => Navigator.of(context).pop(),
                    child: const Text("Dong"),
                  )
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void initState() {
// TODO: implement initState
    super.initState();
    xem = widget.xem;
    user = widget.user;

    if (user!= null) {
      if (xem!= true) { // Cập nhật dữ Liệu
        buttonTitle = "Cập nhật";
        title = "Chinh sửa thông tin";
      }
      txtTen.text = user!.name!;
      txtPhone.text = user!.phone!;
      txtEmail.text = user!.email!;
    }
    else {
      buttonTitle = "Thêm";
      title = "Thêm User";
    }
  }

  @override
  void dispose() {
// TODO: implement dispose
    super.dispose();
    txtTen.dispose();
    txtEmail.dispose();
    txtPhone.dispose();
  }

  _capNhat(BuildContext context) async {
    if (xem == true) { // đóng màn hình
      Navigator.of(context).pop();
    }
    else {
      DatabaseProvider provider = context.read<DatabaseProvider>();
      User nUser = User(
          name: txtTen.text,
          phone: txtPhone.text,
          email: txtEmail.text
      );
      if (user == null) { // Thêm mới
        int id = -1;
        id = await provider.insertUser(nUser);
        if (id > 0) {
          showSnackBar(context, "Da them ${nUser.name}", 3);
        } else {
          showSnackBar(context, "Them ${nUser.name} khong thanh cong", 3);
        }
      }
      else { // Cập nhật dữ liệu
        int count = 0;
        count = await provider.updateUser(nUser, user !.id!);
        if (count > 0) {
          showSnackBar(context, "Dã cap nhật ${user !.name!}", 3);
        } else {
          showSnackBar(
              context, "Cap nhat ${user !.name!} khong thanh cong", 3);
        }
      }
    }
  }
}