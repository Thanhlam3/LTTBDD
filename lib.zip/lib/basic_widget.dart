import 'package:flutter/material.dart';

class PageBasicWiget extends StatefulWidget {
  const PageBasicWiget({super.key});

  @override
  State<PageBasicWiget> createState() => _PageBasicWigetState();
}

class _PageBasicWigetState extends State<PageBasicWiget> {
  TextEditingController txtTen = TextEditingController();
  TextEditingController txtSDT = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("BASIC WIDGETS"),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            TextField( //txt ho ten
              controller: txtTen,
              decoration: InputDecoration(
                labelText: "Họ Tên",
                hintText: "Nhập tên vào đây",
              ),
            ),
            TextField( // txt sdt
              controller: txtSDT,
              decoration: InputDecoration(
                labelText: "Số điện thoại",
                hintText: "Nhập số điện thoại vào đây",
              ),
              keyboardType: TextInputType.phone,
            ),

            ElevatedButton( // khi ấn nút messaage thì có 1 thông báo xuất hiện 2s rồi tự mất
                onPressed: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                          content: Text("xin chao: ${txtTen.text}"),
                        duration: Duration(seconds: 2),
                      ),
                  );
                },
                child: Text("message")
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Column(
                  children: [
                    IconButton(
                        onPressed: () {

                        },
                        icon: Icon(Icons.call) // thêm color
                    )
                  ],
                ),
                Column(
                  children: [
                    IconButton(
                        onPressed: () {

                        },
                        icon: Icon(Icons.call)
                    )
                  ],
                ),
                Column(
                  children: [
                    IconButton(
                        onPressed: () {

                        },
                        icon: Icon(Icons.call)
                    )
                  ],
                ),

              ],
            )
          ],
        ),

      ),
    );
  }
}
