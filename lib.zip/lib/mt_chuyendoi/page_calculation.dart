import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lamthanh/mt_chuyendoi/controller_mt.dart';


class PageCalculation extends StatelessWidget {

  PageCalculation({super.key});

  final TextEditingController txtcm = TextEditingController();
  final TextEditingController txtinches = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Pham Thanh Lam "),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
      ),
      body: GetBuilder(
          init: controller_mt(),
          builder: (controller) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("chieu dai (cm)"),
                TextField(
                  controller: txtcm,
                  keyboardType: TextInputType.number,
                ),
                SizedBox(width: 20,),
                Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      ElevatedButton(
                          onPressed: () {
                            controller.cm_inch(txtcm.text);
                            txtinches.text = controller.kq;
                            controller.refresh_mt();
                          },
                          child: Icon(Icons.arrow_downward)
                      ),
                      SizedBox(width: 20,),
                      ElevatedButton(
                          onPressed: () {
                            controller.inch_cm(txtinches.text);
                            txtcm.text = controller.kq;
                            controller.refresh_mt();
                          },
                          child: Icon(Icons.arrow_upward)
                      ),
                    ]
                ),
                Text("chieu dai (inches)"),
                TextField(
                  controller: txtinches,
                  keyboardType: TextInputType.number,
                ),
                Text("ket qua tinh toan"),
                Expanded( // lõi hasSize nên dùng expaned
                  child: ListView.builder(
                    itemCount: controller.kqs.length,
                    itemBuilder: (context, index) {
                      return ListTile(
                          title: Text(controller.kqs[index]),
                      );
                    },
                  ),
                ),
              ],
            );
          },
      )
    );
  }
}
