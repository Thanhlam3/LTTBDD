import 'package:get/get.dart';

class controller_mt extends GetxController{
  List<String> kqs = [];
  String kq = "";

  void cm_inch(String val){
    double num1 = double.parse(val);
    kq = (num1/2.54).toStringAsFixed(2);
    kqs.insert(0, "$val cm = $kq inches");

  }
  void inch_cm(String val){
    double num1 = double.parse(val);
    kq = (num1*2.54).toStringAsFixed(2);
    kqs.insert(0, "$val inches = $kq cm");

  }
  void refresh_mt(){
    update();
  }

}