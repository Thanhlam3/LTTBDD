List<String> loaiMHs = ["phone", "laptop", "TV", "Tu lanh"];

class MatHang{
  String? name, loaiMH;
  int? soluong;

  MatHang({
    this.name,
    this.loaiMH,
    this.soluong,
  });
}
