import 'package:flutter/material.dart';

import 'form_model.dart';

class PageFormMathang extends StatelessWidget {
  PageFormMathang({super.key});
  GlobalKey<FormState> formState = GlobalKey<FormState>();
  MatHang m = MatHang();
  TextEditingController txtName = TextEditingController();
  TextEditingController txtSoLuong = TextEditingController();
  String? dropdownValue;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Pham Thanh Lam Form "),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Form(
          key: formState,
          autovalidateMode: AutovalidateMode.disabled,
          child: Column(
            children: [
              TextFormField(
                controller: txtName,
                onSaved: (newValue) => m.name = newValue,
                validator: (value) => validateString(value),
                decoration: InputDecoration(
                  labelText: "Ten mat hang",
                ),
              ),
              DropdownButtonFormField<String>(
                  items: loaiMHs.map((
                      loaiMH) => DropdownMenuItem<String>(
                      child: Text("${loaiMH}"),
                    value: loaiMH,
                  )).toList(),

                  onChanged: (value) => dropdownValue = value,
                  onSaved: (newValue) => m.loaiMH = newValue,
                  value: dropdownValue,
                  validator: (value) => validateString(value),
                  decoration: InputDecoration(
                    labelText: "Loai mat hang"
                  ),
              ),
              TextFormField(
                controller: txtSoLuong,
                keyboardType: .number,
                onSaved: (newValue) => m.soluong = int.parse(newValue!),
                validator: (value) => validateSoluong(value),
                decoration: InputDecoration(
                  labelText: "So Luong",
                )
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  ElevatedButton(
                      onPressed: () => _save(context),
                      child: Text("save")
                  ),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }

  void _save(BuildContext context) {
    if(formState.currentState!.validate()){
      formState.currentState!.save();
      hienThiDialog(context);
    }
  }
  validateString(String? value){
    return value == null || value.isEmpty ? "ban chua nhap du lieu" : null;
  }
  validateSoluong(String? value){
    if(value == null || value.isEmpty)
      return "ban chua nhap so luong";
    else
      return int.parse(value) < 0 ? "so luonh ko dc phep am" : null;
  }

  void hienThiDialog(BuildContext context) {
    var dialog = AlertDialog(
      title: Text("Thong bao"),
      content: Column(
        crossAxisAlignment: .start,
        mainAxisSize: .min,
        children: [
          Text("Ten mat hang: ${m.name}"),
          Text("Loai hang: ${m.loaiMH}"),
          Text("So luong: ${m.soluong}"),
        ],
      ),
      actions: [
        ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
            },
            child: Text("ok")
        )
      ],
    );
    showDialog(
        context: context,
        builder: (context) => dialog,
    );
  }

}
