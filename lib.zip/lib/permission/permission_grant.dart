import 'package:permission_handler/permission_handler.dart';

class PermissionHelper {
  // Ngăn chặn việc tạo instance của class này vì chúng ta chỉ dùng static methods
  PermissionHelper._();

  /// Yêu cầu quyền truy cập Camera
  static Future<bool> requestCameraPermission() async {
    return await requestPermission(Permission.camera);
  }

  /// Hàm dùng chung để yêu cầu bất kỳ quyền nào
  static Future<bool> requestPermission(Permission permission) async {
    // 1. Kiểm tra xem quyền đã được cấp trước đó chưa
    if (await permission.isGranted) {
      return true;
    }

    // 2. Nếu chưa, tiến hành yêu cầu cấp quyền
    PermissionStatus status = await permission.request();

    if (status.isGranted) {
      return true;
    }

    // 3. Nếu người dùng chọn "Không bao giờ hỏi lại" (Permanently Denied)
    // Mở cài đặt của hệ thống để người dùng tự bật
    if (status.isPermanentlyDenied) {
      await openAppSettings();
    }

    return false;
  }
}