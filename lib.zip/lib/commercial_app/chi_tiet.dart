import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lamthanh/commercial_app/model/fruit.dart';
import 'package:badges/badges.dart' as badges;
import 'package:lamthanh/commercial_app/page_gio_hang.dart';
import 'controller_fruit_store.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';

import 'model/supabase_helper.dart';
import 'page_login.dart';

class PageChitiet extends StatelessWidget {
  PageChitiet({super.key, required this.fruit});
  Fruit fruit;
  final controller = Get.put(ControllerFruitStore());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Fruit store 2"),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        actions: [
          GetBuilder<ControllerFruitStore>(
              init: controller,
              id: "gioHang",
              builder: (controller) {
                return GestureDetector(
                  onTap: () => Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (context) => PageGioHang(),
                      )
                  ),
                  child: badges.Badge(
                    showBadge: controller.sslMHGH>0,
                    badgeContent: Text("${controller.sslMHGH}", style: TextStyle(color: Colors.white),),
                    child: Icon(Icons.shopping_cart_outlined, color: Colors.black, size: 30,),
                  ),
                );
              }
          ),
          SizedBox(width: 20,) , // dung sizebox de day the badge ra or boc bang padding


        ],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(5.0),
          child: Column(
            crossAxisAlignment: .start,
            children: [
              Image.network(fruit.anh?? "No image"),
              SizedBox(height: 10,),
              Text("${fruit.ten}"),
              Row(
                children: [
                  Text("${fruit.gia?? 0}", style: TextStyle(color: Colors.red),),
                  SizedBox(width: 25,),
                  Text("${(fruit.gia?? 0)*120/100}", style: TextStyle(decoration: .lineThrough),)
                ],
              ),
              Text(fruit.moTa?? "", style: TextStyle(fontStyle: .italic),),
              Row(
                children: [
                  RatingBarIndicator(
                    rating: 4.5,
                    itemSize: 30,
                    itemBuilder: (context, index) {
                      return Icon(Icons.star,color: Colors.orange, );
                      },
                  ),
                  SizedBox(width: 20,),
                  Text("100 danh gia")
                ],
              ),
        
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
          onPressed: () {
            if (supabase.auth.currentUser != null) {
                var state = controller.themMH_vao_GH2(fruit);
               if (state==false) {
              controller.themMH_vao_GH2(fruit);
              ScaffoldMessenger.of(context).clearMaterialBanners();
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text(
                    "Da cap nhat so luong mat hang ${fruit
                        .ten} thanh ${controller.gioHang[fruit.id]!.soLuong}")
                ),
              );
              }
            }
            else{
              Get.to(() => PageLogin());
            }
          },
          child: Icon(Icons.add_shopping_cart_sharp),

      ),

    );
  }
}
