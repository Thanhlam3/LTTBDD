import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lamthanh/commercial_app/chi_tiet.dart';
import 'package:lamthanh/commercial_app/controller_fruit_store.dart';
import 'package:lamthanh/commercial_app/model/fruit.dart';
import 'package:badges/badges.dart' as badges;
import 'package:supabase_flutter/supabase_flutter.dart';

import 'model/supabase_helper.dart';
import 'page_login.dart';

class PageFruit2 extends StatelessWidget {
  PageFruit2({super.key});
  final controller = Get.put(ControllerFruitStore());
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Fruit store 2"),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        actions: [
          GetBuilder<ControllerFruitStore>(
            init: controller,
            id: "gioHang",
            builder: (controller) {
              return badges.Badge(
                showBadge: controller.sslMHGH>0,
                badgeContent: Text("${controller.sslMHGH}", style: TextStyle(color: Colors.white),),
                child: Icon(Icons.shopping_cart_outlined, color: Colors.black, size: 30,),
              );

            }

          ),
          SizedBox(width: 20,),  // dung sizebox de day the badge ra or boc bang padding
        ],

      ),
        drawer: Drawer(
          child: StreamBuilder<AuthState>(
            // Lắng nghe sự thay đổi trạng thái đăng nhập của Supabase
              stream: supabase.auth.onAuthStateChange,
              builder: (context, snapshot) {
                final user = supabase.auth.currentUser;
                return ListView(
                  children: [
                    UserAccountsDrawerHeader(
                      // Nếu đã đăng nhập thì hiện xin chào, chưa thì hiện thông báo
                      accountName: Text(
                        user != null ? "Xin chào!" : "Chưa đăng nhập",
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 16),
                      ),
                      // Nếu đã đăng nhập thì hiện email, chưa thì hiện câu nhắc nhở
                      accountEmail: Text(
                          user?.email ?? "Vui lòng đăng nhập để mua hàng"),
                    ),
                    if (user == null)
                      ListTile(
                        leading: Icon(Icons.login),
                        title: Text("Đăng nhập"),
                        onTap: () {
                          // Đóng Drawer trước khi chuyển trang
                          Navigator.pop(context);
                          // Chuyển sang trang Login
                          Get.to(() => PageLogin());
                        },
                      )
                    else
                      ListTile(
                        leading: Icon(Icons.logout, color: Colors.red),
                        title: Text(
                            "Đăng xuất", style: TextStyle(color: Colors.red)),
                        onTap: () async {
                          // Xử lý đăng xuất
                          await supabase.auth.signOut();
                          // Xóa dữ liệu giỏ hàng cục bộ nếu cần thiết
                          controller.gioHang.clear();
                          controller.update(["gioHang"]);

                          Navigator.pop(context);
                        },
                      ),

                    Divider(thickness: 1.5),
                  ],
                );
              }
          )
        ),
      body: GetBuilder<ControllerFruitStore>(
          id: "fruits",
          init: controller,
          builder: (controller) {
            List<Fruit> list = controller.mapFruit.values.toList();
            return Padding(
              padding: const EdgeInsets.all(5.0),
              child: GridView.extent(
                maxCrossAxisExtent: 250,
                crossAxisSpacing: 5,
                childAspectRatio: 0.75,
                children: list.map(
                      (e) {
                    return GestureDetector( // widget de them nhieu cu chi, vd on tap
                      onTap: () {
                        Navigator.of(context).push(
                          MaterialPageRoute(builder: (context) => PageChitiet(fruit: e),)
                        );
                      },
                      child: Card(

                        child: Column(
                          children: [
                            Image.network(e.anh?? "No image"),
                            Text(e.ten),
                            Text("${e.gia?? 0}")
                          ],
                        ),
                      ),
                    );
                  },
                ).toList(),
              ),
            );
          },
      )
    );

  }
}
