import 'package:flutter/material.dart';
import 'package:lamthanh/commercial_app/model/fruit.dart';

class PageFruitStream extends StatelessWidget {
  const PageFruitStream({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Fruit store"),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
      ),
      body: StreamBuilder<List<Fruit>>(
          stream: FruitSnapshot.getFruitStream(),
          builder: (context, snapshot) {
            if(snapshot.hasError){
              print("loi x1: "+ snapshot.error.toString());
              return Center(child: Text("loi xx2"),);
            }
            if(!snapshot.hasData){
              return Center(child: Column(
                children: [
                  CircularProgressIndicator(),
                  Text("dang chay...")
                ],
              ),
              );
            }
            return GridView.extent(
                maxCrossAxisExtent: 300,
                children: snapshot.data!.map(
                    (e) {
                      return Column(
                        children: [
                          Text(e.ten),
                          Image.network(
                            e.anh!,
                            width: 100,
                            height: 100,
                          )
                        ],
                      );
                    },
                ).toList()
            );
          },
      ),
    );
  }
}
