import 'package:lamthanh/commercial_app/model/supabase_helper.dart';
import 'package:supabase_flutter/supabase_flutter.dart';


class Fruit{

  int id;
  int? gia;
  String ten;
  String? moTa, anh;

  Fruit({
    required this.id,
    this.gia,
    required this.ten,
    this.moTa,
    this.anh,
  });

  factory Fruit.fromJson(Map<String, dynamic> json) {
    return Fruit(
      id: json['id'] as int,
      gia: json['gia'] as int?,
      ten: json['ten'] as String,
      moTa: json['moTa'] as String?,
      anh: json['anh'] as String?,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': this.id,
      'gia': this.gia,
      'ten': this.ten,
      'moTa': this.moTa,
      'anh': this.anh,
    };
  }
  Map<String, dynamic> toJson() {
    return {
      'id': this.id,
      'gia': this.gia,
      'ten': this.ten,
      'moTa': this.moTa,
      'anh': this.anh,
    };
  }

  factory Fruit.fromMap(Map<String, dynamic> map) {
    return Fruit(
      id: map['id'] as int,
      gia: map['gia'] as int,
      ten: map['ten'] as String,
      moTa: map['moTa'] as String,
      anh: map['anh'] as String,
    );
  }
}

class FruitSnapshot{
  static Stream<List<Fruit>> getFruitStream(){
    final supabase = Supabase.instance.client;
    var stream = supabase.from('Fruit')
        .stream(primaryKey: ['id']);
    return stream.map((mapList) => 
        mapList.map((map) => Fruit.fromJson(map)
          ,).toList()
      ,);
  }

  // static Future<Map<int, Fruit>> getMapFruit() async{
  //   final supabase =  Supabase.instance.client;
  //   final data = await supabase
  //       .from('Fruit')
  //       .select();
  //   var iterable = data.map(
  //         (e) => Fruit.fromJson(e),
  //   );
  //   Map<int, Fruit> _map = Map.fromIterable(
  //     iterable,
  //     value:(element) => element   ,
  //     key: (element) => element.id,
  //   );
  //   return _map;
  // }

 static Future<Map<int, Fruit>> getMapFruit_() async{
    return getMapData<Fruit>(
      table: "Fruit",
      fromJson: (json) => Fruit.fromJson(json),
      getID: (t) => t.id,);
  }

  static Future<void> insert(Fruit fruit) async{
    await supabase
        .from("Fruit")
        .insert(fruit.toJson());
  }

  static Future<void> update(Fruit newFruit) async{
    await supabase
        .from('Fruit')
        .update( newFruit.toJson() )
        .eq('id', newFruit.id);
  }
  static Future<void> deleteImage({required String bucket, required String path}) async{
    await supabase
        .storage
        .from(bucket)
        .remove([path]);
  }

  static Future<void> delete(int id) async{
    await supabase
        .from('Fruit')
        .delete()
        .eq('id', id);
    await deleteImage(bucket: "images", path: "fruits_${id}.jpg");
  }

  static ListenDatachanges (Map<int, Fruit> maps, {Function()? updateUI}){
    supabase
        .channel('public:Fruit')
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: 'Fruit',
          callback: (payload) {
            switch(payload.eventType){
              case PostgresChangeEvent.insert:
              case PostgresChangeEvent.update:{
                Fruit f = Fruit.fromJson(payload.newRecord);
                maps[f.id] = f;
                updateUI?.call();
                break;
            }
              case PostgresChangeEvent.delete:{
                maps.remove(payload.oldRecord["id"]);
                updateUI?.call();
                break;
              }
              default:{}
            }
          })
        .subscribe();
  }


}





