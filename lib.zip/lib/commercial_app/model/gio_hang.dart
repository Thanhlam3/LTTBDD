import 'package:lamthanh/commercial_app/model/supabase_helper.dart';

class GioHangItem {
  int id, soluong;
  bool chon;
  GioHangItem({
    required this.id,
    this.soluong = 1,
    this.chon = false,
  });
}

class GioHangItem2{
  int? id;
  String? uid;
  int fruitId, soLuong;
  bool chon;

  GioHangItem2({
    this.id,
    this.uid,
    required this.fruitId,
    this.soLuong = 1,
    this.chon = false,
  });

  Map<String, dynamic> toMap() {
    final map = <String, dynamic>{

      'uid': this.uid,
      'fruitId': this.fruitId,
      'soLuong': this.soLuong,
      'chon': this.chon,
    };


    if (this.id != null) {
      map['id'] = this.id;
    }

    return map;
  }

  factory GioHangItem2.fromMap(Map<String, dynamic> map) {
    return GioHangItem2(
      id: map['id'] as int,
      uid: map['uid'] as String,
      fruitId: map['fruitId'] as int,
      soLuong: map['soLuong'] as int,
      chon: map['chon'] as bool,
    );
  }

}
class GioHangItem2Snapshot{
  static Future<Map<int, GioHangItem2>> getGioHang (String uid){
    return getMapDataFliter(
        table: "GioHang",
        filtercolum: "uid",
        fliterValue: uid,
        fromJson: (json) => GioHangItem2.fromMap(json),
        getID: (t) => t.fruitId,
    );
  }
  static Future<int> them(GioHangItem2 item)async {
    try {
      await supabase.from("GioHang").insert(item.toMap());
      return 1;
    }
    catch(e){
      print("loi them vao gio hang: ${e.toString()}");
      return 0;
    }
  }
  static Future<int> capNhat(GioHangItem2 item)async {
    try{
      await supabase.from("GioHang").update(item.toMap()).eq("uid", item.uid!).eq("fruitId", item.fruitId);
      return 1;
    }
    catch(e){
      print("loi cap nhat vao gio hang: ${e.toString()}");
      return 0;
    }
  }
}
