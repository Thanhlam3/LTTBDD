

import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:lamthanh/vd/list_view.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

final supabase =  Supabase.instance.client;


Future<Map<int, T>> getMapData<T>({
  required String table,
  required T Function(Map<String, dynamic> json) fromJson,
  required int Function(T t) getID
}) async{

  final data = await supabase.from(table).select();
  var iterable = data.map(
        (e) => fromJson(e),
  );
  Map<int, T> _map = Map.fromIterable(
    iterable,
    value:(element) => element   ,
    key: (element) => getID(element),
  );
  return _map;
}

// void listenSignOut(void Function() signOutCallback){
//   supabase.auth.onAuthStateChange.listen((data){
//     final AuthChangeEvent event = data.event;
//     if(event == AuthChangeEvent.signedOut){
//       signOutCallback.call();
//     }
//   });
// }

Future<Map<int, T>> getMapDataFliter<T>({
  required String table,
  required String filtercolum,
  required String fliterValue,
  required T Function(Map<String, dynamic> json) fromJson,
  required int Function(T t) getID
}) async{

  final data = await supabase.from(table).select().eq(filtercolum, fliterValue);
  var iterable = data.map(
        (e) => fromJson(e),
  );
  Map<int, T> _map = Map.fromIterable(
    iterable,
    value:(element) => element   ,
    key: (element) => getID(element),
  );
  return _map;
}

Future<String> upLoadImage({
  required File image,
  required String bucket,
  required String path,
  bool upsert = false
}) async{
  await supabase.storage.from(bucket).upload(
      path,
      image,
      fileOptions: FileOptions(cacheControl: '3600', upsert: upsert),
  );
  final String publicUrl = supabase.storage.from(bucket).getPublicUrl(path);
  return publicUrl + "?ts=${DateTime.now().microsecond}";
}

Future<String> updateImage({
  required File image,
  required String bucket,
  required String path,
  bool upsert = false
}) async {
  await supabase.storage.from(bucket).update(
      path, 
      image,
      fileOptions: FileOptions(cacheControl: '3600', upsert: upsert),
  );
  final String publicUrl = supabase.storage.from(bucket).getPublicUrl(path);
  return publicUrl + "?ts=${DateTime.now().microsecond}";
}

Future<void> deleteImg({
  required String bucket,
  required String path
}) async{
  await supabase.storage.from(bucket).remove([path]);
}

Future<AuthResponse> supabaseSignUp({
  required String email,
  required String password,
}) {
  return supabase.auth.signUp(
    email: email,
    password: password,
  );
}

Future<AuthResponse> supabseSignIn({
  required String email,
  required String password,
}) {
  return supabase.auth.signInWithPassword(
    email: email,
    password: password,
  );
}
