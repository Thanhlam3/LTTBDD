import 'package:get/get.dart';
import 'package:lamthanh/commercial_app/model/gio_hang.dart';
import 'package:lamthanh/commercial_app/model/supabase_helper.dart';

import 'model/fruit.dart';

class ControllerFruitStore extends GetxController{
  Map<int, Fruit> mapFruit = {};
  Map<int, GioHangItem2> gioHang = {};

  int get sslMHGH => gioHang.length;
  @override
  void onReady() {
    // TODO: implement onReady
    super.onReady();
    FruitSnapshot.getMapFruit_().then(
      (value) {
        mapFruit = value;
        update(["fruits"]);
      },
    ).onError(
      (error, stackTrace) {
        print("loi doc bang fruit: ${error.toString()}");
      },
    );
    
    if(supabase.auth.currentUser!=null){
      getgioHang();
    }
  }
void getgioHang(){
  GioHangItem2Snapshot.getGioHang(supabase.auth.currentUser!.id)
      .then(
        (value) {
      gioHang = value;
      update(["gioHang"]);
    },
  ).onError(
        (error, stackTrace) {
      print("loi doc bang fruit: ${error.toString()}");
    },
  );
}
  bool themMH_vao_GH(Fruit f){
    if(gioHang.containsKey(f.id)){
      gioHang[f.id]!.soLuong = gioHang[f.id]!.soLuong +1;
      return false;
    }
    gioHang[f.id] = new GioHangItem2(fruitId: f.id);
    update(["giohang"]);
    refresh();
    return true;
  }

  Future<bool> themMH_vao_GH2(Fruit f)async{
    if(gioHang.containsKey(f.id)){
      gioHang[f.id]!.soLuong += 1;
      var numUpdate = await GioHangItem2Snapshot.capNhat(gioHang[f.id]!);
      if(numUpdate==0){
        gioHang[f.id]!.soLuong -= 1;
      }
      return false;
    }
    GioHangItem2 item = new GioHangItem2(fruitId: f.id, uid: supabase.auth.currentUser!.id);
    var num = await GioHangItem2Snapshot.them(item);
    if(num==1) {
      gioHang[f.id] = item;
      update(["gioHang"]);
    }
    return true;
  }



  // Bật/tắt trạng thái chọn của một mặt hàng trong giỏ
  void nutChon(int id, bool value) {
    if (gioHang.containsKey(id)) {
      gioHang[id]!.chon = value;
      update(["gioHang"]);
    }
  }

  // Tăng hoặc giảm số lượng
  void capNhatSoLuong(int id, int delta) {
    if (gioHang.containsKey(id)) {
      gioHang[id]!.soLuong += delta;
      // Nếu số lượng <= 0 thì tự động xóa khỏi giỏ hàng
      if (gioHang[id]!.soLuong <= 0) {
        gioHang.remove(id);
      }
      update(["gioHang"]);
    }
  }

  // Getter tính tổng tiền các mặt hàng đã được tick chọn
  int get tongTien {
    int tong = 0;
    gioHang.forEach((key, item) {
      if (item.chon) {
        tong += ((mapFruit[item.fruitId]!.gia ?? 0).toInt()) * item.soLuong;

      }
    });
    return tong;
  }

}

class ControllerFruitStoreAdmin extends GetxController{
  Map<int, Fruit> mapFruit = {};
  List<Fruit> list = <Fruit>[].obs;
  void onReady() {
    // TODO: implement onReady
    super.onReady();
    // FruitSnapshot.getMapFruit_().then(
    //       (value) {
    //     mapFruit = value;
    //     update(["fruit_admin"]);
    //   },
    // ).onError(
    //       (error, stackTrace) {
    //     print("loi doc bang fruit: ${error.toString()}");
    //   },
    // );

    // FruitSnapshot.ListenDatachanges(
    //   mapFruit,
    //   updateUI: () => update(["fruit_admin"]),
    // );
  }
  @override
  void dispose(){
   // FruitSnapshot.unsubriceListenDatachanges();
  }

}