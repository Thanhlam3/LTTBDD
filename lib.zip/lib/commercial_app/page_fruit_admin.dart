import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:lamthanh/commercial_app/controller_fruit_store.dart';
import 'package:lamthanh/commercial_app/model/fruit.dart';
import 'package:lamthanh/commercial_app/model/supabase_helper.dart';

class PageFruitAdmin extends StatelessWidget {
  PageFruitAdmin({super.key});
  //final ControllerFruitStoreAdmin controller = Get.put(ControllerFruitStoreAdmin());
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Fruit store admin"),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        actions: [
          IconButton(
              onPressed: () {
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => PageFruitAdd(),)
                );
              }, 
              icon: Icon(Icons.add_circle_outline, size: 35,)
          )
        ],
      ),
      body: SafeArea(
          child: StreamBuilder<List<Fruit>>(
            stream: FruitSnapshot.getFruitStream(),
            builder: (context, snapshot) {
              if(snapshot.hasError){
                return Center(
                  child: Text("lỗi"),
                );
            }
            if(!snapshot.hasData){
              return Center(
                child: CircularProgressIndicator(),
              );
            }
              var list = snapshot.data!;
              return Padding(
                padding: const EdgeInsets.all(5.0),
                child: ListView.separated(
                    itemBuilder: (context, index) {
                      Fruit fruit = list[index];
                      return Row(
                        children: [
                          SizedBox(
                            width: 100,
                            child: Image.network(fruit.anh?? ""),
                          ),
                          Column(
                            crossAxisAlignment: .start,
                            children: [
                              Text(fruit.ten),
                              Text("${fruit.gia} vnd",style: TextStyle(color: Colors.red, fontSize: 18,)),
                              Text(fruit.moTa?? "", style: TextStyle(fontStyle: .italic),),
                            ],
                          )
                        ],
                      );
                    },
                    separatorBuilder: (context, index) => Divider(),
                    itemCount: list.length
                ),
              );
          },
          )
      ),
    );
  }
}



class PageFruitAdd extends StatefulWidget {
  PageFruitAdd({super.key});
  @override
  State<PageFruitAdd> createState() => _PageFruitAddState();
}

class _PageFruitAddState extends State<PageFruitAdd> {
  XFile? _xFile;
  TextEditingController txtTen = TextEditingController();
  TextEditingController txtGia = TextEditingController();
  TextEditingController txtMoTa = TextEditingController();
  TextEditingController txtID = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("add fruit"),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
      ),
      body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(5.0),
            child: SingleChildScrollView(
              child: Column(
                children: [
                  SizedBox(
                    width: MediaQuery.of(context).size.width*0.8,
                    height: MediaQuery.of(context).size.width*0.8,
                    child: _xFile == null? Center(
                      child: Icon(Icons.image, size: 100,),)
                        :Image.file(File(_xFile!.path),), // fit: .cover để sửa lại ảnh
                  ),
                  Row(
                    mainAxisAlignment: .end,
                    children: [
                      ElevatedButton(
                          onPressed: () async{
                            var imagePicker = await ImagePicker().pickImage(source: .gallery);
                            if(imagePicker!=null){
                              setState(() {
                                _xFile = imagePicker;
                              });
                            }
                          },
                          child: Text("upload img")
                      )
                    ],
                  ),
                  TextField(
                    controller: txtID,
                    decoration: InputDecoration(
                      labelText: "ID",
                    ),
                    keyboardType: .number,
                  ),
                  TextField(
                    controller: txtTen,
                    decoration: InputDecoration(
                      labelText: "Ten san pham",
                      hintText: "nhap ten san pham",
                    ),
                  ),
                  TextField(
                    controller: txtGia,
                    decoration: InputDecoration(
                      labelText: "gia san pham",
                    ),
                    keyboardType: .number,
                  ),
                  TextField(
                    controller: txtMoTa,
                    decoration: InputDecoration(
                      labelText: "mo ta",
                    ),
                  ),
                  Row(
                    mainAxisAlignment: .end,
                    children: [
                      ElevatedButton(
                          onPressed: () {

                          },
                          child: Text("close")
                      ),
                      ElevatedButton(
                          onPressed: () async{
                            // 1. them anh lay url
                            if(_xFile!=null){
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(content: Text("dang them ${txtTen.text} ..."), duration: Duration(seconds: 5),)
                              );
                              String imageUrl = await upLoadImage(
                                  image: File(_xFile!.path),
                                  bucket: "images",
                                  path: "fruits/${txtID.text}.jpg"
                              );
                              // 2. them fruit
                              Fruit fruit = Fruit(
                                  id: int.parse(txtID.text),
                                  ten: txtTen.text,
                                  gia: int.parse(txtGia.text),
                                  moTa: txtMoTa.text,
                                  anh: imageUrl,
                              );
                              await FruitSnapshot.insert(fruit);
                              ScaffoldMessenger.of(context).clearSnackBars();
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(content: Text("da them ${txtTen.text}"), duration: Duration(seconds: 3),)
                              );
                            }
                          },
                          child: Text("save")
                      )
                    ],
                  )
                ],
              ),
            ),
          )
      ),
    );
  }
}

