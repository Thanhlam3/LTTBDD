import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lamthanh/commercial_app/model/gio_hang.dart';
import 'controller_fruit_store.dart';

class PageGioHang extends StatelessWidget {
  PageGioHang({super.key});
  final controller = Get.put(ControllerFruitStore());
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: GetBuilder<ControllerFruitStore>(
            id: "gioHang",
            builder: (controller) => Text("Giỏ hàng (${controller.sslMHGH})"),
          ),

        ),
      body: GetBuilder<ControllerFruitStore>(
        id: "gioHang",
        builder: (controller) {
          return Column(
            children: [

              Expanded(
                  child: ListView.separated(
                      itemBuilder: (context, index) {
                        GioHangItem2 item = controller.gioHang.values.elementAt(index);
                        return Row(
                          children: [
                            Checkbox(
                              value: item.chon?? false,
                              onChanged: (value) {
                                // Gọi hàm trạng thái chọn
                                controller.nutChon(item.fruitId, value ?? false);
                              },
                            ),
                            SizedBox(
                                width: 50, height: 50,
                                child: Image.network(
                                  controller.mapFruit[item.fruitId]?.anh?? "no image",
                                  fit: .scaleDown,
                                )
                            ),
                            SizedBox(width: 5,),
                            Column(
                              crossAxisAlignment: .start,
                              children: [
                                Text(controller.mapFruit[item.fruitId]!.ten?? ""),
                                Row(
                                  children: [
                                    Text("${(controller.mapFruit[item.fruitId]!.gia?? 0)*item.soLuong}"),
                                    SizedBox(width: 10,),
                                    TextButton(
                                        onPressed: () {
                                          // Giảm số lượng đi 1
                                          controller.capNhatSoLuong(item.fruitId, -1);
                                        },
                                        child: Text("-")
                                    ),
                                    Text("${item.soLuong}"),
                                    TextButton(
                                        onPressed: () {
                                          // Tăng số lượng lên 1
                                          controller.capNhatSoLuong(item.fruitId, 1);
                                        },
                                        child: Text("+")
                                    ),
                                  ],
                                )
                              ],
                            )
                          ],
                        );
                      },
                      separatorBuilder: (context, index) => Divider(),
                      itemCount: controller.sslMHGH
                  )
              ),
              Row(
                children: [
                  Expanded(child: Text("tong tien")),
                  SizedBox(width: 20,),


                  Text("${controller.tongTien}"),
                ],
              ),
              SizedBox(height: 40,)

            ],
          );
        },

      ),
    );
  }
}
