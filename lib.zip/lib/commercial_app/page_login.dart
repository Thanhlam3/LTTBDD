import 'package:flutter/material.dart';
import 'package:flutter_otp_text_field/flutter_otp_text_field.dart';
import 'package:get/get.dart';
import 'package:lamthanh/commercial_app/controller_fruit_store.dart';
import 'package:lamthanh/commercial_app/model/supabase_helper.dart';
import 'package:supabase_auth_ui/supabase_auth_ui.dart';

class PageLogin extends StatelessWidget {
  const PageLogin({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Fruit store 3"),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,

      ),
      body: Column(
        mainAxisAlignment:MainAxisAlignment.center,
        children: [
          SupaEmailAuth(
              onSignInComplete: (response) {
                // tai anh danh sach gio hang
                Get.find<ControllerFruitStore>().getgioHang();

                Navigator.of(context).pop();
              },
              onSignUpComplete: (response) {
                if(response?.user != null){
                  Navigator.of(context).push(MaterialPageRoute(
                      builder: (context) => PageVerifyUser(email: response!.user!.email!)
                  )
                  );
                }
              },
            showConfirmPasswordField: true,
          ),
        ],
      ),
    );
  }
}


class PageVerifyUser extends StatelessWidget {
  PageVerifyUser({super.key, required this.email});
  String email;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("xac thuc nguoi dung"),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
      ),
      body: Column(
        mainAxisAlignment: .center,
        children: [
          OtpTextField(
            numberOfFields: 6,
            borderColor: Colors.black,
            //focusedBorderColor: Colors.purpleAccent,
            //styles: otpTextStyles,
            showFieldAsBox: true,
            borderWidth: 4.0,
            fieldWidth: 45,
            textStyle: TextStyle(fontSize: 15),
            //runs when a code is typed in
            onCodeChanged: (String code) {
              //handle validation or checks here if necessary
            },
            //runs when every textfield is filled
            onSubmit: (String verificationCode) async {
              var response = await Supabase.instance.client.auth.verifyOTP(
                  type: .email,
                  token: verificationCode,
                  email: email
              );
              // if(response?.session!=null && response?.user != null) {
              //   Navigator.of(context).pushAndRemoveUntil(
              //     MaterialPageRoute(builder: (context) =>
              //         PageThongTinUser()),
              //         (route) => false,
              //   );
              // }
            },
          ),
        ],
      ),

    );
  }
}


class PageThongTinUser extends StatelessWidget {
  const PageThongTinUser({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("thong tin nguoi dung"),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
      ),
    );
  }
}
