import 'dart:math';

import 'package:flutter/material.dart';

class PageMyListView extends StatelessWidget {
  const PageMyListView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("list view"),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
      ),
      body: ListView.separated(
          itemBuilder: (context, index) {
            // bọc ListTitle bằng widget rồi dùng gesturedetector để dùng sự kiện on tap bao gồm cả 1 mục item ko chỉ riêng title
            // khác với on tap của listTitle chỉ dùng dc khi nhấn trên mục title
            return GestureDetector(
              onTap: () {
                ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text("Bạn chọn ${data[index]}, chúc bạn ăn tết vui vẻ"),
                    )
                );
              },
              child: ListTile(
                title: Text("${data[index]}"),
                subtitle: Text("Giá ${Random().nextInt(100)} 000 vnd"),
                trailing: Text("${Random().nextInt(100)} kg"),
                leading: Image.network("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQk9Y_6wJSr8HAItlWBUl3knIbXULaboNqgow&s"),
              ),
            );
          },
          separatorBuilder: (context, index) => Divider(),
          itemCount: data.length
      )
    );
  }
}
var data = [
  "mãng cầu",
  "dừa",
  "đu đủ",
  "bom",
  "lựu",
  "xoài",
  "sung",
  "táo",
  "dưa hấu",
  "cam",
  "bưởi",
  "thanh long",
  "quýt",
  "lê",
  "mẫn",
  "đào",
];
